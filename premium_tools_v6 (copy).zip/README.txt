VERN PREMIUM TOOLS v6 - REAL COOKIE-BASED FB AUTOMATION
==========================================================

TOOLS INCLUDED:
  [1] Spam Share   - Mass share a post
  [2] AU2 Create   - Auto create Facebook accounts
  [3] FB Clone     - Clone/extract profile data
  [4] Mass Comment - Multi-cookie mass comment poster
  [5] Auto React   - Multi-cookie auto reaction (Like/Love/Haha/Wow/Sad/Angry)
  [6] Web UI       - Localhost web interface (open in browser)

USAGE (Termux):
  1. bash install.sh
  2. python3 premium_tools.py
  
  OR obfuscated:
  python3 run.py

WEB INTERFACE:
  python3 premium_tools.py → select [6] → open browser → http://localhost:8080

COMMENT / REACTION NOTES:
  - Primary method: mbasic HTML form submission
    Works for accounts WITHOUT checkpoint cookie
  - Fallback: www.facebook.com GraphQL API
    Works when mbasic form is unavailable
  - If account is checkpointed: log in fresh and re-export cookies

HOW TOKEN EXTRACTION WORKS (auto, no setup needed):
  - Uses Wget/1.21.1 user-agent + identity encoding on mbasic React SPA
  - Extracts DTSGInitialData + LSD for GraphQL API calls
  - Extracts fb_dtsg + jazoest for mbasic form submissions
  - All done automatically from your cookie

COOKIE FORMAT:
  Paste the full cookie string from browser DevTools → Network tab
  Example: sb=...; c_user=12345; xs=...; fr=...
  
  Multiple cookies (for mass tools): one per line

v6 IMPROVEMENTS OVER v5:
  - Correct token extraction (Wget UA + identity → React SPA tokens)
  - mbasic form-based commenting (primary, reliable)
  - GraphQL fallback with latest doc_ids
  - Better error messages (checkpoint detection, etc.)
  - Reaction type selection (Like/Love/Haha/Wow/Sad/Angry)
  - Threaded mass comment support
  - Web UI auto-reload
