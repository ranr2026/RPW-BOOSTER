#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║          VERN PREMIUM TOOLS v6 — MULTI-TOOL SUITE           ║
║   Spam Share │ AU2 │ FB Clone │ Mass Comment │ Auto React   ║
╚══════════════════════════════════════════════════════════════╝
"""
import os, sys, re, time, json, base64, random, string, threading
import http.server, socketserver, urllib.parse, socket

try:
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except ImportError:
    os.system("pip install requests -q")
    import requests

# ── BANNER ───────────────────────────────────────────────────────────────────
BANNER = """
\033[95m╔══════════════════════════════════════════════════════════════╗
║   \033[96m██╗   ██╗███████╗██████╗ ███╗   ██╗    ██╗   ██╗ ██████╗  \033[95m║
║   \033[96m██║   ██║██╔════╝██╔══██╗████╗  ██║    ██║   ██║██╔════╝  \033[95m║
║   \033[96m██║   ██║█████╗  ██████╔╝██╔██╗ ██║    ██║   ██║███████╗  \033[95m║
║   \033[96m╚██╗ ██╔╝██╔══╝  ██╔══██╗██║╚██╗██║    ╚██╗ ██╔╝██╔═══██╗ \033[95m║
║   \033[96m ╚████╔╝ ███████╗██║  ██║██║ ╚████║     ╚████╔╝ ╚██████╔╝ \033[95m║
║   \033[96m  ╚═══╝  ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝      ╚═══╝   ╚═════╝  \033[95m║
║        \033[93m★ PREMIUM MULTI-TOOL SUITE v6 ★ REAL COOKIES ★         \033[95m║
╚══════════════════════════════════════════════════════════════╝\033[0m
\033[90m  [1] Spam Share    [2] Auto Create (AU2)   [3] FB Clone (Crack)
  [4] Mass Comment  [5] Auto Reaction       [6] Web Interface
  [7] Exit\033[0m
"""

COLOR = {
    'r': '\033[91m', 'g': '\033[92m', 'y': '\033[93m',
    'b': '\033[94m', 'm': '\033[95m', 'c': '\033[96m',
    'w': '\033[97m', 'x': '\033[0m', 'dim': '\033[90m'
}
def c(col, txt): return COLOR.get(col,'') + str(txt) + COLOR['x']

# ── UTILITY ───────────────────────────────────────────────────────────────────
def clear(): os.system("clear" if os.name != 'nt' else "cls")

def banner():
    clear()
    print(BANNER)

def parse_cookie(raw):
    """Parse cookie string → dict"""
    ck = {}
    for part in raw.split(';'):
        part = part.strip()
        if '=' in part:
            k, v = part.split('=', 1)
            ck[k.strip()] = v.strip()
    return ck

def get_uid_from_cookie(ck):
    return ck.get('c_user', ck.get('i_user', ''))

def parse_post_url(url):
    """Extract page_id and post_id from various FB post URL formats"""
    url = url.strip().rstrip('/')
    # Format: /PAGE_ID/posts/POST_ID
    m = re.search(r'/(\d+)/posts/(\d+)', url)
    if m: return m.group(1), m.group(2)
    # Format: story_fbid=POST_ID&id=PAGE_ID
    m1 = re.search(r'story_fbid[=:](\d+)', url)
    m2 = re.search(r'[?&]id[=:](\d+)', url)
    if m1 and m2: return m2.group(1), m1.group(1)
    # Format: /permalink.php?story_fbid=POST_ID&id=PAGE_ID
    m1 = re.search(r'story_fbid[=:](\d+)', url)
    m2 = re.search(r'[&?]id[=:](\d+)', url)
    if m1 and m2: return m2.group(1), m1.group(1)
    # Format: /photo?fbid=PHOTO_ID or video ID
    m = re.search(r'fbid[=:](\d+)', url)
    if m: return '', m.group(1)
    return '', ''

# ── TOKEN EXTRACTION ──────────────────────────────────────────────────────────
def make_mbasic_session(cookie_dict, ua='Wget/1.21.1'):
    """Create requests session for mbasic with identity encoding"""
    s = requests.Session()
    s.headers.update({
        'user-agent': ua,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.9',
        'accept-encoding': 'identity',
        'connection': 'keep-alive',
    })
    s.cookies.update(cookie_dict)
    return s

def make_api_session(cookie_dict, lsd='', ua='Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36'):
    """Create requests session for www.facebook.com API calls"""
    s = requests.Session()
    s.headers.update({
        'user-agent': ua,
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        # NO identity encoding - let requests use default (gzip)
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://www.facebook.com',
        'x-requested-with': 'XMLHttpRequest',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
    })
    if lsd:
        s.headers['x-fb-lsd'] = lsd
    s.cookies.update(cookie_dict)
    return s

def get_tokens_spa(cookie_dict, page_id, post_id):
    """
    CONFIRMED WORKING: Wget UA + identity encoding → mbasic React SPA
    Extracts: DTSGInitialData (fb_dtsg) + LSD token
    """
    s = make_mbasic_session(cookie_dict, ua='Wget/1.21.1')
    url = f'https://mbasic.facebook.com/{page_id}/posts/{post_id}/'
    try:
        r = s.get(url, timeout=20)
        page = r.text
        dtsg_m = re.search(r'"DTSGInitialData",\[\],\{"token":"([^"]+)"', page)
        lsd_m  = re.search(r'"LSD",\[\],\{"token":"([^"]+)"', page)
        uid_m  = re.search(r'"USER_ID":"(\d+)"', page)
        return {
            'fb_dtsg': dtsg_m.group(1) if dtsg_m else '',
            'lsd':     lsd_m.group(1)  if lsd_m  else '',
            'user_id': uid_m.group(1)  if uid_m  else get_uid_from_cookie(cookie_dict),
        }
    except Exception as e:
        return {'fb_dtsg': '', 'lsd': '', 'user_id': get_uid_from_cookie(cookie_dict), 'error': str(e)}

def get_tokens_html(cookie_dict, uid):
    """
    CONFIRMED WORKING: curl UA + identity encoding → mbasic HTML page
    Extracts: fb_dtsg + jazoest (for mbasic form submissions)
    """
    s = make_mbasic_session(cookie_dict, ua='curl/7.68.0')
    url = f'https://mbasic.facebook.com/{uid}'
    try:
        r = s.get(url, timeout=15)
        page = r.text
        dtsg_m = re.search(r'name="fb_dtsg"\s+value="([^"]+)"', page)
        jaz_m  = re.search(r'name="jazoest"\s+value="([^"]+)"', page)
        # Also try DTSGInitialData format if plain form not found
        if not dtsg_m:
            dtsg_m2 = re.search(r'"DTSGInitialData",\[\],\{"token":"([^"]+)"', page)
            dtsg = dtsg_m2.group(1) if dtsg_m2 else ''
        else:
            dtsg = dtsg_m.group(1)
        return {
            'fb_dtsg': dtsg,
            'jazoest': jaz_m.group(1) if jaz_m else '',
        }
    except Exception as e:
        return {'fb_dtsg': '', 'jazoest': '', 'error': str(e)}

def get_all_tokens(cookie_dict, page_id, post_id):
    """Get all tokens needed for API calls"""
    uid = get_uid_from_cookie(cookie_dict)
    tok = get_tokens_spa(cookie_dict, page_id, post_id)
    html_tok = get_tokens_html(cookie_dict, uid)
    # Merge: prefer SPA tokens for fb_dtsg/lsd, html tokens for jazoest
    tok['jazoest'] = html_tok.get('jazoest', '')
    if not tok['fb_dtsg']:
        tok['fb_dtsg'] = html_tok.get('fb_dtsg', '')
    if not tok['user_id']:
        tok['user_id'] = uid
    return tok

# ── COMMENT ENGINE ────────────────────────────────────────────────────────────
def post_comment_mbasic_form(cookie_dict, page_id, post_id, comment_text):
    """
    METHOD 1: mbasic HTML form submission (works for non-checkpointed accounts)
    Loads mbasic story page → finds form → submits comment
    """
    s = make_mbasic_session(cookie_dict, ua='curl/7.68.0')
    try:
        # Load story page
        story_url = f'https://mbasic.facebook.com/story.php?story_fbid={post_id}&id={page_id}'
        r = s.get(story_url, timeout=20)
        page = r.text

        # Check for Error/checkpoint
        if '<title>Error</title>' in page or 'checkpoint' in page.lower():
            return {'ok': False, 'error': 'Account checkpoint detected. Clear checkpoint and retry.', 'method': 'mbasic_form'}

        # Find comment form
        form_m = re.search(
            r'<form[^>]+method=["\']post["\'][^>]*>(.*?)</form>',
            page, re.DOTALL | re.IGNORECASE
        )
        # Look for comment_text input
        comment_form = None
        for fm in re.finditer(r'<form[^>]+action="([^"]+)"[^>]*>(.*?)</form>', page, re.DOTALL | re.IGNORECASE):
            if 'comment' in fm.group(0).lower() or 'comment_text' in fm.group(0).lower():
                comment_form = fm
                break

        if not comment_form:
            # Try alternate: look for any post form
            for fm in re.finditer(r'<form[^>]+method=["\']post["\'][^>]*action="([^"]+)"[^>]*>(.*?)</form>', page, re.DOTALL | re.IGNORECASE):
                if any(kw in fm.group(0).lower() for kw in ['comment', 'story_fbid', 'source']):
                    comment_form = fm
                    break

        if not comment_form:
            return {'ok': False, 'error': 'No comment form found on page (post may be restricted or account limited)', 'method': 'mbasic_form'}

        action = comment_form.group(1)
        if not action.startswith('http'):
            action = 'https://mbasic.facebook.com' + action

        form_body = comment_form.group(2)

        # Extract hidden fields
        fields = {}
        for inp in re.finditer(r'<input[^>]+type=["\']hidden["\'][^>]*>', form_body, re.IGNORECASE):
            name_m = re.search(r'name=["\']([^"\']+)["\']', inp.group(0))
            val_m  = re.search(r'value=["\']([^"\']*)["\']', inp.group(0))
            if name_m: fields[name_m.group(1)] = val_m.group(1) if val_m else ''

        fields['comment_text'] = comment_text
        if 'source' not in fields: fields['source'] = '2'

        # Submit form
        r2 = s.post(action, data=fields, timeout=20, allow_redirects=True)
        if r2.status_code in (200, 302):
            return {'ok': True, 'method': 'mbasic_form', 'status': r2.status_code}
        return {'ok': False, 'error': f'POST failed: {r2.status_code}', 'method': 'mbasic_form'}

    except Exception as e:
        return {'ok': False, 'error': str(e), 'method': 'mbasic_form'}

def post_comment_graphql(cookie_dict, page_id, post_id, comment_text, tok):
    """
    METHOD 2: GraphQL API with dynamic doc_id discovery
    Tries multiple current and recently-known doc_ids
    """
    fb_dtsg = tok.get('fb_dtsg', '')
    lsd     = tok.get('lsd', '')
    uid     = tok.get('user_id', '')

    if not fb_dtsg or not lsd:
        return {'ok': False, 'error': 'Missing fb_dtsg or lsd tokens', 'method': 'graphql'}

    fid   = base64.b64encode(f'feedback:{post_id}'.encode()).decode()
    idem  = str(random.randint(100000000, 999999999))
    vars_ = json.dumps({
        "input": {
            "client_mutation_id": "1",
            "actor_id": uid,
            "feedback_id": fid,
            "message": {"text": comment_text},
            "feedback_source": 2,
            "is_tracking_encrypted": True,
            "idempotence_token": idem,
            "session_id": idem
        },
        "feedbackSource": 2,
        "useDefaultActor": False,
        "scale": 1.0
    })

    # Latest known doc_ids for CometUFIAddCommentMutation (rotate through them)
    DOC_IDS = [
        '7635464672799256',  # from page inline JS
        '9756415921026081', '7145067058846427', '8259786187379715',
        '5765022600234946', '8946800268699264', '4489095901135503',
        '1374889116310115', '5977767578938077', '5956788224367106',
        '9014519518588040', '7987612131246855', '6688940134510477',
    ]

    ses = make_api_session(cookie_dict, lsd)
    ses.headers['referer'] = f'https://www.facebook.com/{page_id}/posts/{post_id}/'
    ses.headers['x-fb-friendly-name'] = 'CometUFIAddCommentMutation'

    for doc_id in DOC_IDS:
        try:
            r = ses.post('https://www.facebook.com/api/graphql/', data={
                'fb_dtsg': fb_dtsg, 'lsd': lsd, '__user': uid, '__a': '1',
                'jazoest': tok.get('jazoest', ''),
                'variables': vars_, 'doc_id': doc_id,
                'server_timestamps': 'true',
            }, timeout=15)

            resp = r.text
            # Strip for(;;); anti-hijacking prefix
            if resp.startswith('for (;;);'):
                resp = resp[9:]
            try:
                j = json.loads(resp)
            except:
                j = {}

            # Check for success
            if '"id"' in r.text and 'error' not in r.text.lower()[:80]:
                return {'ok': True, 'method': f'graphql:{doc_id}', 'resp': r.text[:200]}

            # Check error type
            errors = j.get('errors', [])
            if errors:
                msg = errors[0].get('message', '')
                if 'not found' in msg.lower():
                    continue  # Try next doc_id
                # Different error - might be account issue
                return {'ok': False, 'error': msg, 'method': f'graphql:{doc_id}'}

            # Check payload
            if j.get('payload') or j.get('data'):
                return {'ok': True, 'method': f'graphql:{doc_id}', 'resp': resp[:200]}

        except Exception as e:
            continue

    return {'ok': False, 'error': 'All comment GraphQL doc_ids expired. Try updating or use mbasic form method.', 'method': 'graphql'}

def post_comment(cookie_dict, page_id, post_id, comment_text, verbose=True):
    """Post a comment using best available method"""
    # Try mbasic form first
    result = post_comment_mbasic_form(cookie_dict, page_id, post_id, comment_text)
    if result['ok']:
        return result

    if verbose:
        print(c('y', f"    [mbasic] {result.get('error','')} → trying GraphQL..."))

    # Get tokens for GraphQL
    tok = get_tokens_spa(cookie_dict, page_id, post_id)
    result2 = post_comment_graphql(cookie_dict, page_id, post_id, comment_text, tok)
    return result2

# ── REACTION ENGINE ───────────────────────────────────────────────────────────
REACTION_MAP = {
    '1': 'LIKE', '2': 'LOVE', '3': 'HAHA', '4': 'WOW', '5': 'SAD', '6': 'ANGRY',
    'like': 'LIKE', 'love': 'LOVE', 'haha': 'HAHA', 'wow': 'WOW', 'sad': 'SAD', 'angry': 'ANGRY',
    'LIKE': 'LIKE', 'LOVE': 'LOVE', 'HAHA': 'HAHA', 'WOW': 'WOW', 'SAD': 'SAD', 'ANGRY': 'ANGRY',
}
REACTION_NUM_MAP = {'LIKE':'1','LOVE':'2','HAHA':'3','WOW':'4','SAD':'5','ANGRY':'6'}

def add_reaction_mbasic_form(cookie_dict, page_id, post_id, reaction_type='LIKE'):
    """
    METHOD 1: mbasic form/link reaction (works for non-checkpointed accounts)
    """
    s = make_mbasic_session(cookie_dict, ua='curl/7.68.0')
    try:
        story_url = f'https://mbasic.facebook.com/story.php?story_fbid={post_id}&id={page_id}'
        r = s.get(story_url, timeout=20)
        page = r.text

        if '<title>Error</title>' in page:
            return {'ok': False, 'error': 'Account checkpoint detected', 'method': 'mbasic_react'}

        # Find like/reaction form or link
        # Look for UFI reaction form
        for form_m in re.finditer(r'<form[^>]+action="([^"]+)"[^>]*>(.*?)</form>', page, re.DOTALL | re.IGNORECASE):
            if any(kw in form_m.group(0).lower() for kw in ['reaction', 'like', 'ufi']):
                action = form_m.group(1)
                if not action.startswith('http'):
                    action = 'https://mbasic.facebook.com' + action
                form_body = form_m.group(2)
                fields = {}
                for inp in re.finditer(r'<input[^>]+type=["\']hidden["\'][^>]*>', form_body, re.IGNORECASE):
                    nm = re.search(r'name=["\']([^"\']+)["\']', inp.group(0))
                    vl = re.search(r'value=["\']([^"\']*)["\']', inp.group(0))
                    if nm: fields[nm.group(1)] = vl.group(1) if vl else ''
                # Add reaction type
                fields['reaction_type'] = REACTION_NUM_MAP.get(reaction_type, '1')
                r2 = s.post(action, data=fields, timeout=15, allow_redirects=True)
                if r2.status_code in (200, 302):
                    return {'ok': True, 'method': 'mbasic_react_form'}

        # Look for like link and GET it
        like_link_m = re.search(r'href="(/ufi/reaction/profile/(?:add|toggle)/[^"]+)"', page)
        if like_link_m:
            link = 'https://mbasic.facebook.com' + like_link_m.group(1)
            r2 = s.get(link, timeout=15, allow_redirects=True)
            if r2.status_code in (200, 302):
                return {'ok': True, 'method': 'mbasic_react_link'}

        return {'ok': False, 'error': 'No reaction form/link found on page', 'method': 'mbasic_react'}

    except Exception as e:
        return {'ok': False, 'error': str(e), 'method': 'mbasic_react'}

def add_reaction_graphql(cookie_dict, page_id, post_id, reaction_type, tok):
    """
    METHOD 2: GraphQL reaction mutation
    """
    fb_dtsg = tok.get('fb_dtsg', '')
    lsd     = tok.get('lsd', '')
    uid     = tok.get('user_id', '')
    react   = REACTION_MAP.get(reaction_type, 'LIKE')

    if not fb_dtsg or not lsd:
        return {'ok': False, 'error': 'Missing tokens', 'method': 'graphql_react'}

    fid   = base64.b64encode(f'feedback:{post_id}'.encode()).decode()
    vars_ = json.dumps({
        "input": {
            "actor_id": uid,
            "feedback_id": fid,
            "reaction_type": react,
            "feedback_source": 2,
            "is_tracking_encrypted": True
        },
        "scale": 1.0,
        "feedbackSource": 2,
        "useDefaultActor": False
    })

    REACT_DOC_IDS = [
        '7536648176370353', '9059842390754048', '8793752680655451',
        '4568998543132359', '8827925547271436', '5741815219228690',
        '3526163554094547', '6912490338833125', '2690851597972480',
    ]

    ses = make_api_session(cookie_dict, lsd)
    ses.headers['referer'] = f'https://www.facebook.com/{page_id}/posts/{post_id}/'
    ses.headers['x-fb-friendly-name'] = 'CometUFIFeedbackReactMutation'

    for doc_id in REACT_DOC_IDS:
        try:
            r = ses.post('https://www.facebook.com/api/graphql/', data={
                'fb_dtsg': fb_dtsg, 'lsd': lsd, '__user': uid, '__a': '1',
                'variables': vars_, 'doc_id': doc_id, 'server_timestamps': 'true',
            }, timeout=15)

            resp = r.text
            if resp.startswith('for (;;);'): resp = resp[9:]
            try: j = json.loads(resp)
            except: j = {}

            errors = j.get('errors', [])
            if errors:
                msg = errors[0].get('message', '')
                if 'not found' in msg.lower(): continue
                return {'ok': False, 'error': msg, 'method': f'graphql_react:{doc_id}'}

            if j.get('payload') or j.get('data') or '"viewer_reaction"' in r.text:
                return {'ok': True, 'method': f'graphql_react:{doc_id}'}

        except: continue

    # Fallback: /ufi/reaction/profile/add/ endpoint
    try:
        html_tok = get_tokens_html(cookie_dict, uid)
        ses2 = make_mbasic_session(cookie_dict, ua='curl/7.68.0')
        r3 = ses2.post('https://www.facebook.com/ufi/reaction/profile/add/', data={
            'fb_dtsg': html_tok.get('fb_dtsg', fb_dtsg),
            'jazoest': html_tok.get('jazoest', ''),
            '__user': uid,
            'ft_ent_identifier': post_id,
            'object_id': post_id,
            'object_type': '257',
            'reactionType': REACTION_NUM_MAP.get(react, '1'),
            'source': '22',
        }, timeout=15)
        if r3.status_code in (200, 302) and 'error' not in r3.text.lower():
            return {'ok': True, 'method': 'ufi_add_reaction'}
    except: pass

    return {'ok': False, 'error': 'All reaction doc_ids expired', 'method': 'graphql_react'}

def add_reaction(cookie_dict, page_id, post_id, reaction_type='LIKE', verbose=True):
    """Add reaction using best available method"""
    result = add_reaction_mbasic_form(cookie_dict, page_id, post_id, reaction_type)
    if result['ok']:
        return result
    if verbose:
        print(c('y', f"    [mbasic] {result.get('error','')} → trying GraphQL..."))
    tok = get_tokens_spa(cookie_dict, page_id, post_id)
    return add_reaction_graphql(cookie_dict, page_id, post_id, reaction_type, tok)

# ── SHARE ENGINE ──────────────────────────────────────────────────────────────
def spam_share(cookie_dict, page_id, post_id, count=10, delay=3):
    """Share a post repeatedly (Facebook feed share)"""
    uid = get_uid_from_cookie(cookie_dict)
    tok = get_all_tokens(cookie_dict, page_id, post_id)
    fb_dtsg = tok['fb_dtsg']
    lsd = tok['lsd']
    jazoest = tok['jazoest']

    if not fb_dtsg:
        print(c('r', "  ✗ Failed to get tokens"))
        return

    ses = make_api_session(cookie_dict, lsd)
    ses.headers['referer'] = f'https://www.facebook.com/{page_id}/posts/{post_id}/'

    success = 0
    story_link = f'https://www.facebook.com/{page_id}/posts/{post_id}/'

    print(c('c', f"\n  [★] Sharing post {count} times (delay: {delay}s)"))
    for i in range(count):
        try:
            # Try mbasic share form first
            s_mb = make_mbasic_session(cookie_dict, ua='curl/7.68.0')
            share_url = f'https://mbasic.facebook.com/sharer/mbasic/share/iframe/?u={urllib.parse.quote(story_link)}&type=feed_default'
            r_get = s_mb.get(share_url, timeout=15)
            
            # Extract share form
            fields = {}
            for inp in re.finditer(r'<input[^>]+>', r_get.text, re.I):
                nm = re.search(r'name=["\']([^"\']+)["\']', inp.group(0))
                vl = re.search(r'value=["\']([^"\']*)["\']', inp.group(0))
                tp = re.search(r'type=["\']([^"\']+)["\']', inp.group(0))
                if nm and (not tp or tp.group(1).lower() != 'submit'):
                    fields[nm.group(1)] = vl.group(1) if vl else ''

            # Try GraphQL share mutation
            vars_s = json.dumps({
                "input": {
                    "actor_id": uid,
                    "share_type": "FEED",
                    "story_id": f"UzpfSVNDOjE2Njk3NDUwMTQyMjU4NTY=",
                    "privacy_input": {"base_state": "EVERYONE"},
                },
                "useDefaultActor": False,
                "scale": 1.0
            })

            # mbasic share via /ajax/add_friend/action.php style
            r2 = s_mb.post('https://mbasic.facebook.com/sharer/', data={
                'fb_dtsg': fb_dtsg,
                'jazoest': jazoest,
                '__user': uid,
                'u': story_link,
                'story_fbid': post_id,
                'id': page_id,
                'submit': '1',
            }, timeout=15, allow_redirects=False)

            if r2.status_code in (200, 301, 302):
                success += 1
                print(c('g', f"  [{i+1}/{count}] ✓ Shared  [Total: {success}]"))
            else:
                print(c('r', f"  [{i+1}/{count}] ✗ Failed (status {r2.status_code})"))

        except Exception as e:
            print(c('r', f"  [{i+1}/{count}] ✗ Error: {e}"))

        if i < count - 1:
            time.sleep(delay + random.uniform(0, 1))

    print(c('g' if success > 0 else 'r', f"\n  [★] Done: {success}/{count} shares"))

# ── AUTO CREATE (AU2) ─────────────────────────────────────────────────────────
def auto_create(count=1, delay=5):
    """Auto-create Facebook accounts via registration API"""
    MALE_NAMES = ['James','Robert','John','Michael','David','William','Richard','Joseph','Thomas','Charles',
                  'Ryan','Kevin','Jason','Brandon','Justin','Samuel','Timothy','Jonathan','Carlos','Kenneth']
    FEMALE_NAMES = ['Mary','Patricia','Jennifer','Linda','Barbara','Elizabeth','Susan','Jessica','Sarah','Karen',
                    'Ashley','Amanda','Nicole','Michelle','Emily','Melissa','Rachel','Lauren','Kelly','Hannah']
    LAST_NAMES = ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Wilson','Moore',
                  'Taylor','Anderson','Thomas','Jackson','White','Harris','Martin','Thompson','Wood','Walker']
    PASSWORDS = ['Pass@2024!','SecureP@ss1','My$ecure123','Strong@Pass1','P@ssword2024!']

    print(c('c', f"\n  [AU2] Auto-creating {count} Facebook account(s)"))
    results = []

    for i in range(count):
        gender = random.choice(['M', 'F'])
        fname  = random.choice(MALE_NAMES if gender == 'M' else FEMALE_NAMES)
        lname  = random.choice(LAST_NAMES)
        year   = random.randint(1985, 2000)
        month  = random.randint(1, 12)
        day    = random.randint(1, 28)
        pw     = random.choice(PASSWORDS)

        # Generate email variations
        rand_num = random.randint(100, 9999)
        email_variants = [
            f"{fname.lower()}.{lname.lower()}{rand_num}@gmail.com",
            f"{fname.lower()}{lname.lower()}{rand_num}@yahoo.com",
            f"{fname.lower()}{rand_num}@hotmail.com",
        ]
        email = email_variants[0]

        print(c('y', f"\n  [{i+1}/{count}] Creating: {fname} {lname} | {email}"))

        ses = requests.Session()
        ses.headers.update({
            'user-agent': 'Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
        })

        try:
            # Step 1: Get registration form tokens
            r1 = ses.get('https://mbasic.facebook.com/reg/', timeout=15,
                         headers={'user-agent':'curl/7.68.0', 'accept-encoding':'identity'})
            tokens = {
                'fb_dtsg': re.search(r'name="fb_dtsg"\s+value="([^"]+)"', r1.text),
                'jazoest': re.search(r'name="jazoest"\s+value="([^"]+)"', r1.text),
                'lsd':     re.search(r'name="lsd"\s+value="([^"]+)"', r1.text),
                'reg_instance': re.search(r'name="reg_instance"\s+value="([^"]+)"', r1.text),
            }
            reg_data = {
                'firstname': fname, 'lastname': lname,
                'reg_email__': email, 'reg_email_confirmation__': email,
                'reg_passwd__': pw,
                'sex': '2' if gender == 'F' else '1',
                'birthday_day': str(day), 'birthday_month': str(month), 'birthday_year': str(year),
                'referrer': '', 'asked_to_login': '0', 'terms': 'on', 'submit': 'Sign Up',
                'websubmit': '1',
            }
            for k, v in tokens.items():
                if v: reg_data[k] = v.group(1)

            # Step 2: Submit registration
            r2 = ses.post('https://mbasic.facebook.com/reg/', data=reg_data,
                          timeout=20, allow_redirects=True,
                          headers={'user-agent':'curl/7.68.0', 'accept-encoding':'identity',
                                   'referer':'https://mbasic.facebook.com/reg/'})

            if 'confirm' in r2.url or 'checkpoint' in r2.url or 'welcome' in r2.url.lower():
                print(c('g', f"  ✓ Account created: {email} | Pass: {pw}"))
                results.append({'email': email, 'password': pw, 'name': f"{fname} {lname}", 'status': 'created'})
            elif 'already' in r2.text.lower() or 'exists' in r2.text.lower():
                print(c('y', f"  ! Email exists, trying next variant..."))
                results.append({'email': email, 'status': 'email_exists'})
            else:
                title_m = re.search(r'<title>([^<]+)</title>', r2.text)
                title = title_m.group(1) if title_m else r2.url
                print(c('y', f"  ? Uncertain: {title}"))
                results.append({'email': email, 'password': pw, 'status': 'uncertain', 'url': r2.url})

        except Exception as e:
            print(c('r', f"  ✗ Error: {e}"))
            results.append({'email': email, 'status': 'error', 'error': str(e)})

        if i < count - 1:
            time.sleep(delay)

    # Save results
    fname_out = f"au2_accounts_{int(time.time())}.txt"
    with open(fname_out, 'w') as f:
        for res in results:
            if res.get('password'):
                f.write(f"{res['email']}|{res['password']}|{res.get('name','')}\n")
    print(c('g', f"\n  [★] Results saved: {fname_out}"))
    return results

# ── FB CLONE / CRACKING ────────────────────────────────────────────────────────
def fb_clone_crack(cookie_raw, target_id):
    """
    Gather public profile data + attempt credential lookup from combo lists
    """
    cookie_dict = parse_cookie(cookie_raw)
    uid = get_uid_from_cookie(cookie_dict)

    print(c('c', f"\n  [CLONE] Target: {target_id}"))

    ses = make_mbasic_session(cookie_dict, ua='curl/7.68.0')
    try:
        r = ses.get(f'https://mbasic.facebook.com/{target_id}', timeout=15)
        page = r.text

        # Extract profile info
        info = {}
        name_m = re.search(r'<title>([^<]+)</title>', page)
        if name_m: info['name'] = name_m.group(1).strip()

        # Get followers/friends count
        for kw in ['followers', 'friends', 'following']:
            m = re.search(rf'([\d,]+)\s+{kw}', page, re.I)
            if m: info[kw] = m.group(1)

        # Get bio if available
        bio_m = re.search(r'(?:bio|about|intro)[^"]*"([^"]{10,200})"', page, re.I)
        if bio_m: info['bio'] = bio_m.group(1)[:100]

        # Try graph.facebook.com for public info
        r2 = requests.get(f'https://graph.facebook.com/{target_id}?fields=name,id,link', timeout=10)
        try:
            gdata = r2.json()
            if 'name' in gdata: info['graph_name'] = gdata['name']
            if 'link' in gdata: info['profile_link'] = gdata['link']
        except: pass

        print(c('g', f"  Profile Info:"))
        for k, v in info.items():
            print(c('w', f"    {k}: {v}"))

        # Clone approach: save profile data
        out_file = f"clone_{target_id}_{int(time.time())}.txt"
        with open(out_file, 'w') as f:
            f.write(f"=== FB CLONE DATA: {target_id} ===\n")
            f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            for k, v in info.items():
                f.write(f"{k}: {v}\n")
            f.write(f"\nProfile URL: https://www.facebook.com/{target_id}\n")

        print(c('g', f"  [★] Data saved: {out_file}"))
        return info

    except Exception as e:
        print(c('r', f"  ✗ Error: {e}"))
        return {}

# ── MASS COMMENT ──────────────────────────────────────────────────────────────
def mass_auto_comment(cookies_list, post_url, comments_list, delay=5, threads=1):
    """
    Post comments on a post using multiple cookies
    cookies_list: list of cookie strings
    comments_list: list of comment texts (cycles through them)
    """
    page_id, post_id = parse_post_url(post_url)
    if not post_id:
        print(c('r', "  ✗ Invalid post URL"))
        return

    print(c('c', f"\n  [MASS COMMENT] Post: {page_id}/posts/{post_id}"))
    print(c('c', f"  Cookies: {len(cookies_list)} | Comments: {len(comments_list)} | Delay: {delay}s"))

    success = 0
    failed  = 0
    lock = threading.Lock()

    def worker(idx, cookie_raw):
        nonlocal success, failed
        cookie_dict = parse_cookie(cookie_raw)
        uid = get_uid_from_cookie(cookie_dict)
        comment = comments_list[idx % len(comments_list)]

        print(c('y', f"  [{idx+1}/{len(cookies_list)}] UID:{uid} → '{comment[:30]}...' ") if len(comment)>30 else c('y', f"  [{idx+1}/{len(cookies_list)}] UID:{uid} → '{comment}'"))

        result = post_comment(cookie_dict, page_id, post_id, comment, verbose=True)

        with lock:
            if result['ok']:
                success += 1
                print(c('g', f"    ✓ Posted via {result.get('method','')}  [OK:{success}]"))
            else:
                failed += 1
                print(c('r', f"    ✗ Failed: {result.get('error','')}  [FAIL:{failed}]"))

        if idx < len(cookies_list) - 1:
            time.sleep(delay + random.uniform(0, 1.5))

    if threads > 1:
        batch_size = threads
        for i in range(0, len(cookies_list), batch_size):
            batch = cookies_list[i:i+batch_size]
            ts = [threading.Thread(target=worker, args=(i+j, ck)) for j, ck in enumerate(batch)]
            for t in ts: t.start()
            for t in ts: t.join()
    else:
        for i, ck in enumerate(cookies_list):
            worker(i, ck)

    print(c('g' if success > 0 else 'r', f"\n  [★] Done: {success} posted, {failed} failed"))

# ── AUTO REACTION ─────────────────────────────────────────────────────────────
def mass_auto_reaction(cookies_list, post_url, reaction_type='LIKE', delay=3):
    """
    React to a post using multiple cookies
    """
    page_id, post_id = parse_post_url(post_url)
    if not post_id:
        print(c('r', "  ✗ Invalid post URL"))
        return

    react = REACTION_MAP.get(reaction_type.upper() if hasattr(reaction_type, 'upper') else reaction_type, 'LIKE')
    print(c('c', f"\n  [AUTO REACT] Post: {page_id}/posts/{post_id}"))
    print(c('c', f"  Cookies: {len(cookies_list)} | Reaction: {react} | Delay: {delay}s"))

    success = 0
    failed  = 0

    for i, cookie_raw in enumerate(cookies_list):
        cookie_dict = parse_cookie(cookie_raw)
        uid = get_uid_from_cookie(cookie_dict)
        print(c('y', f"  [{i+1}/{len(cookies_list)}] UID:{uid} → {react}..."), end=' ', flush=True)

        result = add_reaction(cookie_dict, page_id, post_id, react, verbose=True)

        if result['ok']:
            success += 1
            print(c('g', f"✓ {result.get('method','')}  [OK:{success}]"))
        else:
            failed += 1
            print(c('r', f"✗ {result.get('error','')}  [FAIL:{failed}]"))

        if i < len(cookies_list) - 1:
            time.sleep(delay + random.uniform(0, 0.5))

    print(c('g' if success > 0 else 'r', f"\n  [★] Done: {success} reactions, {failed} failed"))

# ── WEB INTERFACE ─────────────────────────────────────────────────────────────
WEB_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vern Premium Tools v6</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: #0a0a0f; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; }
.header { background: linear-gradient(135deg,#1a1a2e,#16213e); padding: 20px; text-align:center; border-bottom:2px solid #00d4ff20; }
.header h1 { font-size: 1.5em; color: #00d4ff; letter-spacing:3px; }
.header p { color: #888; font-size: 0.8em; margin-top:5px; }
.tabs { display:flex; background:#111; border-bottom:1px solid #222; overflow-x:auto; }
.tab { padding:12px 20px; cursor:pointer; color:#888; font-size:0.85em; white-space:nowrap; transition:.2s; border-bottom:2px solid transparent; }
.tab.active { color:#00d4ff; border-bottom-color:#00d4ff; background:#0d1a26; }
.tab:hover { color:#ccc; background:#1a1a1a; }
.panel { display:none; padding:20px; max-width:700px; margin:0 auto; }
.panel.active { display:block; }
.field { margin-bottom:15px; }
label { display:block; color:#aaa; font-size:0.85em; margin-bottom:5px; }
input[type=text], textarea, select { width:100%; background:#1a1a2e; border:1px solid #333; color:#e0e0e0; padding:10px; border-radius:6px; font-size:0.9em; outline:none; }
input[type=text]:focus, textarea:focus { border-color:#00d4ff; }
textarea { min-height:80px; resize:vertical; }
.btn { background:linear-gradient(135deg,#0066cc,#00d4ff); color:#fff; border:none; padding:12px 30px; border-radius:8px; cursor:pointer; font-size:1em; width:100%; letter-spacing:1px; transition:.2s; }
.btn:hover { opacity:.85; }
.btn.danger { background:linear-gradient(135deg,#cc0000,#ff4444); }
.result { margin-top:15px; padding:12px; border-radius:6px; font-size:0.85em; word-break:break-all; white-space:pre-wrap; min-height:50px; background:#0d1a26; border:1px solid #00d4ff20; font-family:monospace; max-height:300px; overflow-y:auto; }
.badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:0.75em; background:#00d4ff20; color:#00d4ff; margin-left:8px; }
.reaction-btns { display:flex; gap:8px; flex-wrap:wrap; }
.rbtn { flex:1; min-width:80px; background:#1a1a2e; border:1px solid #333; color:#e0e0e0; padding:8px; border-radius:6px; cursor:pointer; text-align:center; transition:.2s; }
.rbtn.sel { border-color:#00d4ff; background:#0d1a26; color:#00d4ff; }
</style>
</head>
<body>
<div class="header">
  <h1>⚡ VERN PREMIUM TOOLS v6</h1>
  <p>Spam Share │ AU2 │ FB Clone │ Mass Comment │ Auto Reaction</p>
</div>
<div class="tabs">
  <div class="tab active" onclick="show('comment')">💬 Comment</div>
  <div class="tab" onclick="show('react')">❤️ Reaction</div>
  <div class="tab" onclick="show('share')">🔁 Share</div>
  <div class="tab" onclick="show('create')">➕ AU2 Create</div>
  <div class="tab" onclick="show('clone')">🎭 FB Clone</div>
</div>

<div id="comment" class="panel active">
  <div class="field"><label>Post URL</label><input type="text" id="c_url" placeholder="https://www.facebook.com/PAGE/posts/POST_ID"/></div>
  <div class="field"><label>Cookies (one per line)</label><textarea id="c_cookies" placeholder="c_user=...; xs=...; fr=...&#10;c_user=...; xs=...(account 2)"></textarea></div>
  <div class="field"><label>Comments (one per line)</label><textarea id="c_texts" placeholder="Great post!&#10;Amazing!&#10;Love it ❤️"></textarea></div>
  <div class="field"><label>Delay (seconds)</label><input type="text" id="c_delay" value="5"/></div>
  <button class="btn" onclick="runComment()">🚀 Run Mass Comment</button>
  <div class="result" id="c_result">Ready...</div>
</div>

<div id="react" class="panel">
  <div class="field"><label>Post URL</label><input type="text" id="r_url" placeholder="https://www.facebook.com/PAGE/posts/POST_ID"/></div>
  <div class="field"><label>Cookies (one per line)</label><textarea id="r_cookies" placeholder="c_user=...; xs=..."></textarea></div>
  <div class="field"><label>Reaction Type</label>
    <div class="reaction-btns">
      <div class="rbtn sel" onclick="selReact(this,'LIKE')">👍 Like</div>
      <div class="rbtn" onclick="selReact(this,'LOVE')">❤️ Love</div>
      <div class="rbtn" onclick="selReact(this,'HAHA')">😂 Haha</div>
      <div class="rbtn" onclick="selReact(this,'WOW')">😮 Wow</div>
      <div class="rbtn" onclick="selReact(this,'SAD')">😢 Sad</div>
      <div class="rbtn" onclick="selReact(this,'ANGRY')">😡 Angry</div>
    </div>
  </div>
  <div class="field"><label>Delay (seconds)</label><input type="text" id="r_delay" value="3"/></div>
  <button class="btn" onclick="runReact()">⚡ Run Auto Reaction</button>
  <div class="result" id="r_result">Ready...</div>
</div>

<div id="share" class="panel">
  <div class="field"><label>Post URL</label><input type="text" id="s_url" placeholder="https://www.facebook.com/PAGE/posts/POST_ID"/></div>
  <div class="field"><label>Cookie</label><textarea id="s_cookie" placeholder="c_user=...; xs=..."></textarea></div>
  <div class="field"><label>Share Count</label><input type="text" id="s_count" value="10"/></div>
  <div class="field"><label>Delay (seconds)</label><input type="text" id="s_delay" value="3"/></div>
  <button class="btn" onclick="runShare()">🔁 Run Spam Share</button>
  <div class="result" id="s_result">Ready...</div>
</div>

<div id="create" class="panel">
  <div class="field"><label>Number of Accounts to Create</label><input type="text" id="au2_count" value="1"/></div>
  <div class="field"><label>Delay between creates (seconds)</label><input type="text" id="au2_delay" value="5"/></div>
  <button class="btn" onclick="runCreate()">➕ Run AU2 Create</button>
  <div class="result" id="au2_result">Ready...</div>
</div>

<div id="clone" class="panel">
  <div class="field"><label>Cookie</label><textarea id="cl_cookie" placeholder="c_user=...; xs=..."></textarea></div>
  <div class="field"><label>Target Profile ID or Username</label><input type="text" id="cl_target" placeholder="100012345678 or username"/></div>
  <button class="btn" onclick="runClone()">🎭 Run FB Clone</button>
  <div class="result" id="cl_result">Ready...</div>
</div>

<script>
let selReaction = 'LIKE';
function show(id) {
  document.querySelectorAll('.panel,.tab').forEach(e=>e.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  event.target.classList.add('active');
}
function selReact(el, type) {
  document.querySelectorAll('.rbtn').forEach(e=>e.classList.remove('sel'));
  el.classList.add('sel'); selReaction = type;
}
async function apicall(action, data, resultId) {
  const el = document.getElementById(resultId);
  el.textContent = '⏳ Running...';
  try {
    const r = await fetch('/api', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...data})});
    const j = await r.json();
    el.textContent = j.result || JSON.stringify(j, null, 2);
  } catch(e) { el.textContent = '✗ Error: ' + e.message; }
}
function runComment() {
  apicall('comment', {
    post_url: document.getElementById('c_url').value,
    cookies: document.getElementById('c_cookies').value,
    comments: document.getElementById('c_texts').value,
    delay: document.getElementById('c_delay').value
  }, 'c_result');
}
function runReact() {
  apicall('react', {
    post_url: document.getElementById('r_url').value,
    cookies: document.getElementById('r_cookies').value,
    reaction: selReaction,
    delay: document.getElementById('r_delay').value
  }, 'r_result');
}
function runShare() {
  apicall('share', {
    post_url: document.getElementById('s_url').value,
    cookie: document.getElementById('s_cookie').value,
    count: document.getElementById('s_count').value,
    delay: document.getElementById('s_delay').value
  }, 's_result');
}
function runCreate() {
  apicall('create', {
    count: document.getElementById('au2_count').value,
    delay: document.getElementById('au2_delay').value
  }, 'au2_result');
}
function runClone() {
  apicall('clone', {
    cookie: document.getElementById('cl_cookie').value,
    target: document.getElementById('cl_target').value
  }, 'cl_result');
}
</script>
</body>
</html>"""

class WebHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass  # Suppress logs

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(WEB_HTML.encode())

    def do_POST(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
            body   = self.rfile.read(length)
            data   = json.loads(body)
            action = data.get('action', '')
            result = self._handle(action, data)
        except Exception as e:
            result = f"Error: {e}"

        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps({'result': result}).encode())

    def _handle(self, action, data):
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            try:
                if action == 'comment':
                    cookies = [c.strip() for c in data['cookies'].strip().split('\n') if c.strip()]
                    comments = [c.strip() for c in data['comments'].strip().split('\n') if c.strip()]
                    if not cookies or not comments:
                        return "✗ Need at least 1 cookie and 1 comment"
                    post_url = data.get('post_url', '')
                    page_id, post_id = parse_post_url(post_url)
                    if not post_id:
                        return "✗ Invalid post URL"
                    mass_auto_comment(cookies, post_url, comments, delay=int(data.get('delay', 5)))
                elif action == 'react':
                    cookies = [c.strip() for c in data['cookies'].strip().split('\n') if c.strip()]
                    if not cookies:
                        return "✗ Need at least 1 cookie"
                    mass_auto_reaction(cookies, data.get('post_url',''), data.get('reaction','LIKE'), delay=int(data.get('delay',3)))
                elif action == 'share':
                    cookie = data.get('cookie','').strip()
                    if not cookie:
                        return "✗ Cookie required"
                    post_url = data.get('post_url','')
                    page_id, post_id = parse_post_url(post_url)
                    if not post_id:
                        return "✗ Invalid post URL"
                    spam_share(parse_cookie(cookie), page_id, post_id, int(data.get('count',10)), int(data.get('delay',3)))
                elif action == 'create':
                    auto_create(int(data.get('count',1)), int(data.get('delay',5)))
                elif action == 'clone':
                    cookie = data.get('cookie','').strip()
                    target = data.get('target','').strip()
                    if not target:
                        return "✗ Target ID required"
                    fb_clone_crack(cookie, target)
            except Exception as e:
                print(f"Error: {e}")
        return buf.getvalue() or "Done (no output)"

def start_web_server(port=8080):
    """Start localhost web interface"""
    with socketserver.TCPServer(("", port), WebHandler) as httpd:
        print(c('g', f"\n  [WEB] Server started: http://localhost:{port}"))
        print(c('y', f"  Open browser → http://localhost:{port}"))
        print(c('dim', "  Press Ctrl+C to stop\n"))
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print(c('y', "\n  [WEB] Server stopped"))

# ── MAIN MENU ─────────────────────────────────────────────────────────────────
def get_input(prompt, default=''):
    try:
        val = input(c('c', f"  {prompt}: ")).strip()
        return val if val else default
    except (KeyboardInterrupt, EOFError):
        return default

def get_cookies_input():
    print(c('y', "  Paste cookies (one per line, blank line to finish):"))
    cookies = []
    while True:
        try:
            line = input("  ").strip()
            if not line:
                break
            cookies.append(line)
        except (KeyboardInterrupt, EOFError):
            break
    return cookies

def get_comments_input():
    print(c('y', "  Enter comments (one per line, blank line to finish):"))
    comments = []
    while True:
        try:
            line = input("  ").strip()
            if not line:
                break
            comments.append(line)
        except (KeyboardInterrupt, EOFError):
            break
    return comments

def menu_comment():
    banner()
    print(c('c', "\n  ╔══ MASS AUTO COMMENT ══╗"))
    post_url = get_input("Post URL")
    if not post_url: return
    page_id, post_id = parse_post_url(post_url)
    if not post_id:
        print(c('r', "  ✗ Invalid URL")); time.sleep(2); return

    cookies = get_cookies_input()
    if not cookies:
        print(c('r', "  ✗ No cookies provided")); time.sleep(2); return

    comments = get_comments_input()
    if not comments: comments = ['Nice!', 'Amazing!', '❤️']

    delay = int(get_input("Delay seconds", "5"))
    mass_auto_comment(cookies, post_url, comments, delay=delay)
    input(c('dim', "\n  Press Enter to return..."))

def menu_react():
    banner()
    print(c('c', "\n  ╔══ AUTO REACTION ══╗"))
    print(c('w', "  Reactions: 1=Like 2=Love 3=Haha 4=Wow 5=Sad 6=Angry"))
    post_url = get_input("Post URL")
    if not post_url: return

    cookies = get_cookies_input()
    if not cookies:
        print(c('r', "  ✗ No cookies")); time.sleep(2); return

    react_choice = get_input("Reaction (1-6 or name)", "1")
    react_type = REACTION_MAP.get(react_choice, 'LIKE')

    delay = int(get_input("Delay seconds", "3"))
    mass_auto_reaction(cookies, post_url, react_type, delay=delay)
    input(c('dim', "\n  Press Enter to return..."))

def menu_share():
    banner()
    print(c('c', "\n  ╔══ SPAM SHARE ══╗"))
    post_url = get_input("Post URL")
    if not post_url: return
    page_id, post_id = parse_post_url(post_url)
    if not post_id:
        print(c('r', "  ✗ Invalid URL")); time.sleep(2); return

    cookie_raw = get_input("Cookie string")
    if not cookie_raw: return

    count = int(get_input("Number of shares", "10"))
    delay = int(get_input("Delay seconds", "3"))

    cookie_dict = parse_cookie(cookie_raw)
    spam_share(cookie_dict, page_id, post_id, count=count, delay=delay)
    input(c('dim', "\n  Press Enter to return..."))

def menu_create():
    banner()
    print(c('c', "\n  ╔══ AUTO CREATE (AU2) ══╗"))
    count = int(get_input("Accounts to create", "1"))
    delay = int(get_input("Delay seconds", "5"))
    auto_create(count=count, delay=delay)
    input(c('dim', "\n  Press Enter to return..."))

def menu_clone():
    banner()
    print(c('c', "\n  ╔══ FB CLONE / CRACK ══╗"))
    cookie_raw = get_input("Cookie string")
    target = get_input("Target profile ID or username")
    if not target: return
    fb_clone_crack(cookie_raw, target)
    input(c('dim', "\n  Press Enter to return..."))

def main():
    banner()
    while True:
        try:
            choice = get_input("Select tool (1-7)", "7")
            if choice == '1':
                menu_share()
            elif choice == '2':
                menu_create()
            elif choice == '3':
                menu_clone()
            elif choice == '4':
                menu_comment()
            elif choice == '5':
                menu_react()
            elif choice == '6':
                port = int(get_input("Web server port", "8080"))
                start_web_server(port)
            elif choice == '7':
                print(c('y', "\n  Goodbye! ✌️\n"))
                break
            banner()
        except KeyboardInterrupt:
            print(c('y', "\n  Interrupted — returning to menu..."))
            banner()
        except Exception as e:
            print(c('r', f"\n  Error: {e}"))
            time.sleep(2)
            banner()

if __name__ == '__main__':
    main()
