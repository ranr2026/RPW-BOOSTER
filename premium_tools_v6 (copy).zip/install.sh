#!/data/data/com.termux/files/usr/bin/bash
echo "Installing dependencies..."
pkg install python -y 2>/dev/null
pip install requests --quiet
echo ""
echo "╔══════════════════════════════════╗"
echo "║  VERN PREMIUM TOOLS v6 READY!   ║"
echo "╚══════════════════════════════════╝"
echo ""
echo "Run with: python3 premium_tools.py"
echo "   or: python3 run.py"
