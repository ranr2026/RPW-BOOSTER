#!/data/data/com.termux/files/usr/bin/bash
echo "Installing dependencies..."
pip install requests -q 2>/dev/null || pip3 install requests -q
echo "Launching VERN Premium v7..."
python premium_tools_v7.py
