VERN PREMIUM TOOLS v7 — LARA APK EDITION
==========================================

FILES:
  premium_tools_v7.py  — Main tool (Termux/Python 3.6+)

SETUP (Termux):
  pkg install python
  pip install requests
  python premium_tools_v7.py

FEATURES:
  [1] Spam Share       — Share a post N times
  [2] Auto Create      — Mass Facebook account creation (AU2)
  [3] FB Clone         — Cookie/password cracking
  [4] Mass Comment     — Multi-account comment bombing
  [5] Auto Reaction    — LARA APK engine (4-method fallback)
  [6] Web Interface    — localhost HTML dashboard
  [7] Extract Token    — Get access_token from cookies (Lara method)

LARA APK REACTION ENGINE:
  Method 1: Graph API  (access_token → graph.facebook.com)
  Method 2: GraphQL    (CometUFIFeedbackReactMutation)
  Method 3: UFI        (ufi/reaction/profile/modify/)
  Method 4: mbasic     (form-based POST fallback)

APK ANALYSIS (Lara v1.5.1):
  Package:   com.uzoq.lara
  Backend:   https://www.lara.rest
  Login:     Android WebView → m.facebook.com
  Cookies:   CookieManager.getCookie()
  url.get_token: OAuth dialog → access_token extraction
  url.submit:    graph.facebook.com/{post_id}/reactions
  Reaction types: LIKE LOVE HAHA WOW SAD ANGRY

REACTION TYPES:
  1=LIKE  2=LOVE  3=HAHA  4=WOW  5=SAD  6=ANGRY

NOTE:
  Checkpointed accounts may fail all methods.
  Use fresh, active Facebook accounts.
  Multiple cookies = multiple accounts reacting.

v7 — May 2026
