VERN PREMIUM TOOLS v8 — Lara APK Edition
==========================================

Launch: python3 vern_premium_v8.py
   OR:  python3 run.py

Requirements:
  pip install requests

Tools:
  1. Spam Share       - Share posts N times
  2. Auto Create      - Create Facebook accounts (AU2)
  3. FB Clone/Crack   - Test email:password combos
  4. Mass Comment     - Multi-account comment flood
  5. Auto Reaction    - 6-method reaction engine
  6. Web Interface    - HTML UI on port 8080
  7. Extract Token    - OAuth access_token extraction

Reaction Methods (6 tried in order):
  M1: Graph API with access_token
  M2: mbasic like link + confirm
  M3: UFI reaction endpoint
  M4: GraphQL mutation (8 doc_ids)
  M5: mbasic UFI form
  M6: Lara /get_reactions endpoint
